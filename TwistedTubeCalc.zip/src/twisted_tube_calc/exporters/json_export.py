"""Экспорт/импорт снапшота сессии в JSON (п. 2.5 ТЗ)."""
from __future__ import annotations

import json

from ..models import SessionSnapshot, from_dict, to_dict


def save_session(snapshot: SessionSnapshot, path: str) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(to_dict(snapshot), fh, ensure_ascii=False, indent=2)


def load_session(path: str) -> SessionSnapshot:
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    return from_dict(SessionSnapshot, data)
