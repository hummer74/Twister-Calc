"""Экспорт сводного отчета в PDF (п. 2.5 ТЗ, reportlab)."""
from __future__ import annotations

import os
import sys
import tempfile

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    Image,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from ..models import CalcResult, OptimizationResult, ParsedInput


def _register_fonts() -> tuple[str, str]:
    """Регистрация шрифта с кириллицей. Возвращает (regular, bold)."""
    pkg_root = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.abspath(os.path.join(pkg_root, "..", "..", ".."))
    # В frozen-сборке PyInstaller ресурсы распаковываются в sys._MEIPASS
    frozen_root = getattr(sys, "_MEIPASS", project_root)
    candidates = [
        (os.path.join(frozen_root, "assets", "DejaVuSans.ttf"),
         os.path.join(frozen_root, "assets", "DejaVuSans-Bold.ttf")),
        (os.path.join(project_root, "assets", "DejaVuSans.ttf"),
         os.path.join(project_root, "assets", "DejaVuSans-Bold.ttf")),
        ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
         "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
        ("C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf"),
    ]
    for regular, bold in candidates:
        if os.path.exists(regular):
            try:
                pdfmetrics.registerFont(TTFont("AppFont", regular))
                if os.path.exists(bold):
                    pdfmetrics.registerFont(TTFont("AppFont-Bold", bold))
                else:
                    pdfmetrics.registerFont(TTFont("AppFont-Bold", regular))
                return "AppFont", "AppFont-Bold"
            except Exception:
                continue
    return "Helvetica", "Helvetica-Bold"


def _style(font: str, bold: str) -> dict[str, ParagraphStyle]:
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("t", parent=base["Title"], fontName=bold, fontSize=16),
        "h2": ParagraphStyle("h", parent=base["Heading2"], fontName=bold, fontSize=13),
        "body": ParagraphStyle("b", parent=base["BodyText"], fontName=font, fontSize=10),
        "mono": ParagraphStyle("m", parent=base["Code"], fontName=font, fontSize=9),
    }


def _table(data: list[list], font: str, bold: str) -> Table:
    tbl = Table(data, hAlign="LEFT")
    tbl.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, 0), bold),
        ("FONTNAME", (0, 1), (-1, -1), font),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    return tbl


def export_pdf(inp: ParsedInput, calc: CalcResult,
               opt: OptimizationResult | None, report_text: str,
               path: str, figures: list | None = None) -> None:
    """Сводный отчет: исходные параметры, геометрия, Pf/PEC, графики, пояснения."""
    font, bold = _register_fonts()
    styles = _style(font, bold)
    doc = SimpleDocTemplate(path, pagesize=A4,
                            leftMargin=18 * mm, rightMargin=18 * mm,
                            topMargin=15 * mm, bottomMargin=15 * mm)
    story = [Paragraph("Сводный отчет по расчету теплообменника на витых трубах",
                       styles["title"]),
             Spacer(1, 6 * mm)]

    story.append(Paragraph("Исходные параметры", styles["h2"]))
    story.append(_table([
        ["Параметр", "Межтрубное пр-во", "Трубное пр-во"],
        ["Среда", inp.shell.fluid_name or "—", inp.tube.fluid_name or "—"],
        ["Расход, кг/ч", f"{inp.shell.mass_flow * 3600:.0f}",
         f"{inp.tube.mass_flow * 3600:.0f}"],
        ["T вход, °C", f"{inp.shell.t_in:.1f}", f"{inp.tube.t_in:.1f}"],
        ["T выход, °C", f"{inp.shell.t_out:.1f}", f"{inp.tube.t_out:.1f}"],
        ["ΔP макс., кПа",
         f"{(inp.constraints.dp_shell_max or 0) / 1000:.1f}",
         f"{(inp.constraints.dp_tube_max or 0) / 1000:.1f}"],
    ], font, bold))
    story.append(Spacer(1, 4 * mm))

    geom = inp.tube_geometry
    story.append(Paragraph("Геометрия трубного пучка", styles["h2"]))
    story.append(_table([
        ["Параметр", "Значение"],
        ["Количество труб", str(geom.n_tubes)],
        ["Наружный диаметр x толщина, мм",
         f"{geom.outer_diameter * 1000:.1f} x {geom.wall_thickness * 1000:.1f}"],
        ["Длина, м", f"{geom.length:.2f}"],
        ["Шаг скрутки S, мм", f"{geom.twist_pitch * 1000:.0f}"],
        ["Соотношение осей a/b", f"{geom.axis_ratio:.2f}"],
        ["Эквивалентный диаметр d_e, мм",
         f"{geom.equivalent_diameter * 1000:.2f}"],
        ["Поверхность теплообмена, м2",
         f"{(inp.surface_area or geom.heat_transfer_area):.1f}"],
    ], font, bold))
    story.append(Spacer(1, 4 * mm))

    t = calc.tube
    story.append(Paragraph("Результаты расчета", styles["h2"]))
    story.append(_table([
        ["Параметр", "Значение"],
        ["Режим течения / Re", f"{t.regime.value} / {t.reynolds:.0f}"],
        ["Nu / h, Вт/(м2·К)", f"{t.nusselt:.1f} / {t.h:.1f}"],
        ["f (Дарси) / ΔP tube, кПа", f"{t.friction_factor:.5f} / {t.dp / 1000:.2f}"],
        ["LMTD, °C", f"{calc.lmtd:.2f}"],
        ["Тепловая мощность Q, кВт", f"{calc.heat_duty / 1000:.1f}"],
        ["U, Вт/(м2·К)", f"{calc.u_value:.1f}"],
        ["Фактор эффективности Pf", f"{calc.pf:.3f}"],
        ["PEC (Yang et al., 2011)", f"{calc.pec:.3f}"],
    ], font, bold))
    story.append(Spacer(1, 4 * mm))

    if opt and opt.success:
        story.append(Paragraph("Подобранная оптимальная геометрия", styles["h2"]))
        story.append(_table([
            ["Параметр", "Значение"],
            ["Соотношение осей a/b", f"{opt.best_axis_ratio:.2f}"],
            ["Шаг скрутки S, мм", f"{opt.best_twist_pitch * 1000:.0f}"],
            ["h, Вт/(м2·К)", f"{opt.best_h:.1f}"],
            ["ΔP tube, кПа", f"{opt.best_dp_tube / 1000:.2f}"],
            ["Pf / PEC", f"{opt.pf:.3f} / {opt.pec:.3f}"],
        ], font, bold))
        story.append(Spacer(1, 4 * mm))

    if figures:
        story.append(Paragraph("Графики", styles["h2"]))
        tmpdir = tempfile.mkdtemp(prefix="ttc_pdf_")
        for i, fig in enumerate(figures):
            png = os.path.join(tmpdir, f"fig_{i}.png")
            fig.savefig(png, dpi=110)
            story.append(Image(png, width=160 * mm, height=106 * mm))
            story.append(Spacer(1, 3 * mm))

    story.append(Paragraph("Пояснительная записка", styles["h2"]))
    for paragraph in report_text.split("\n"):
        story.append(Paragraph(paragraph.replace("<", "&lt;") or " ", styles["body"]))

    doc.build(story)
