"""Экспорт расчетных таблиц в XLSX (п. 2.5 ТЗ)."""
from __future__ import annotations

import pandas as pd

from ..models import CalcResult, OptimizationResult, ParsedInput


def export_xlsx(inp: ParsedInput, calc: CalcResult,
                opt: OptimizationResult | None, path: str) -> None:
    """Три листа: исходные данные, результаты, итерации оптимизации."""
    inputs = pd.DataFrame([
        ("Позиция", inp.position, ""),
        ("Среда (межтрубное пр-во)", inp.shell.fluid_name, ""),
        ("Среда (трубное пр-во)", inp.tube.fluid_name, ""),
        ("Расход shell, кг/ч", inp.shell.mass_flow * 3600, ""),
        ("Расход tube, кг/ч", inp.tube.mass_flow * 3600, ""),
        ("T вход shell, °C", inp.shell.t_in, ""),
        ("T выход shell, °C", inp.shell.t_out, ""),
        ("T вход tube, °C", inp.tube.t_in, ""),
        ("T выход tube, °C", inp.tube.t_out, ""),
        ("Паросодержание tube (вх.)", inp.tube.vapor_quality_in, ""),
        ("Паросодержание tube (вых.)", inp.tube.vapor_quality_out, ""),
        ("Кол-во труб", inp.tube_geometry.n_tubes, ""),
        ("Наружный диаметр трубы, мм", inp.tube_geometry.outer_diameter * 1000, ""),
        ("Толщина стенки, мм", inp.tube_geometry.wall_thickness * 1000, ""),
        ("Длина трубы, м", inp.tube_geometry.length, ""),
        ("Число ходов", inp.tube_geometry.n_passes, ""),
        ("Шаг скрутки S, мм", inp.tube_geometry.twist_pitch * 1000, ""),
        ("Соотношение осей a/b", inp.tube_geometry.axis_ratio, ""),
        ("Эквивалентный диаметр d_e, мм", inp.tube_geometry.equivalent_diameter * 1000, ""),
        ("ΔP макс. shell, кПа", (inp.constraints.dp_shell_max or 0) / 1000, ""),
        ("ΔP макс. tube, кПа", (inp.constraints.dp_tube_max or 0) / 1000, ""),
        ("P расчетное shell, кПа", (inp.constraints.p_design_shell or 0) / 1000, ""),
        ("P расчетное tube, кПа", (inp.constraints.p_design_tube or 0) / 1000, ""),
    ], columns=["Параметр", "Значение", "Примечание"])

    t = calc.tube
    results = pd.DataFrame([
        ("Режим течения", t.regime.value),
        ("Скорость в трубах, м/с", round(t.velocity, 3)),
        ("Re", round(t.reynolds, 1)),
        ("Pr", round(t.prandtl, 2)),
        ("Nu", round(t.nusselt, 2)),
        ("h, Вт/(м2·К)", round(t.h, 2)),
        ("f (Дарси)", round(t.friction_factor, 5)),
        ("ΔP tube, кПа", round(t.dp / 1000, 2)),
        ("ΔP shell, кПа", round(calc.shell.dp / 1000, 2)),
        ("Двухфазный режим", "да" if t.two_phase else "нет"),
        ("Паросодержание x", round(t.vapor_quality, 4)),
        ("LMTD, °C", round(calc.lmtd, 2)),
        ("Тепловая мощность Q, кВт", round(calc.heat_duty / 1000, 1)),
        ("U, Вт/(м2·К)", round(calc.u_value, 2)),
        ("Pf", round(calc.pf, 4)),
        ("PEC", round(calc.pec, 4)),
    ], columns=["Параметр", "Значение"])

    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        inputs.to_excel(writer, sheet_name="Исходные данные", index=False)
        results.to_excel(writer, sheet_name="Результаты", index=False)
        if opt and opt.records:
            iters = pd.DataFrame([{
                "Итерация": r.iteration,
                "a/b": r.axis_ratio,
                "S, м": r.twist_pitch,
                "h, Вт/(м2·К)": round(r.h, 2),
                "ΔP tube, кПа": round(r.dp_tube / 1000, 2),
                "Pf": round(r.pf, 4),
                "PEC": round(r.pec, 4),
                "Допустимо": "да" if r.feasible else "нет",
            } for r in opt.records])
            iters.to_excel(writer, sheet_name="Итерации оптимизации", index=False)
