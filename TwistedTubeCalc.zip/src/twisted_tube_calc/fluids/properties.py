"""Блок теплофизических свойств сред: мазут, нефть, двухфазная смесь.

Свойства жидкой/паровой фазы берутся из встроенных справочных таблиц
(data/*.csv) с линейной интерполяцией по температуре. Значения,
извлеченные парсером из отчетов HTRI, имеют приоритет над справочными
(решение заказчика, PLAN.md п. 3).

Свойства двухфазной смеси — по массовому паросодержанию x
(гомогенная модель): 1/rho_m = x/rho_v + (1-x)/rho_l и т.д.
"""
from __future__ import annotations

import csv
import os
from typing import Optional

import numpy as np

from ..models import FluidProperties, Phase

_DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

FLUID_FILES = {
    "мазут": ("mazut.csv", "mazut_vapor.csv"),
    "нефть": ("oil.csv", "oil_vapor.csv"),
}

_ALIASES = {
    "mazut": "мазут", "мазут": "мазут", "мазутная фракция": "мазут",
    "oil": "нефть", "нефть": "нефть", "crude": "нефть",
}


class FluidTable:
    """Справочная таблица свойств с линейной интерполяцией по температуре."""

    COLUMNS = ("density_kg_m3", "viscosity_Pa_s", "conductivity_W_mK",
               "cp_J_kgK", "latent_heat_J_kg")

    def __init__(self, path: str):
        self.t: list[float] = []
        self.values: dict[str, list[float]] = {c: [] for c in self.COLUMNS}
        with open(path, newline="", encoding="utf-8") as fh:
            for row in csv.reader(fh):
                if not row or row[0].strip().startswith("#"):
                    continue
                cells = [c.strip() for c in row]
                self.t.append(float(cells[0]))
                for i, col in enumerate(self.COLUMNS):
                    raw = cells[i + 1] if i + 1 < len(cells) else ""
                    self.values[col].append(float(raw) if raw else float("nan"))
        self._t = np.asarray(self.t)
        self._v = {k: np.asarray(v) for k, v in self.values.items()}

    def _interp(self, column: str, temp_c: float) -> Optional[float]:
        arr = self._v[column]
        mask = ~np.isnan(arr)
        if not mask.any():
            return None
        return float(np.interp(temp_c, self._t[mask], arr[mask]))

    def properties_at(self, name: str, temp_c: float, phase: Phase) -> FluidProperties:
        return FluidProperties(
            name=name,
            temperature_c=temp_c,
            density=self._interp("density_kg_m3", temp_c) or 800.0,
            viscosity=self._interp("viscosity_Pa_s", temp_c) or 1.0e-3,
            conductivity=self._interp("conductivity_W_mK", temp_c) or 0.12,
            cp=self._interp("cp_J_kgK", temp_c) or 2200.0,
            phase=phase,
            latent_heat=self._interp("latent_heat_J_kg", temp_c),
        )


class FluidModel:
    """Фасад доступа к свойствам сред с приоритетом данных из HTRI."""

    def __init__(self, data_dir: str = _DATA_DIR):
        self._tables: dict[str, tuple[FluidTable, FluidTable]] = {}
        for key, (liq_file, vap_file) in FLUID_FILES.items():
            self._tables[key] = (
                FluidTable(os.path.join(data_dir, liq_file)),
                FluidTable(os.path.join(data_dir, vap_file)),
            )

    @staticmethod
    def normalize_name(name: str) -> str:
        key = (name or "").strip().lower()
        return _ALIASES.get(key, "нефть")

    def available_fluids(self) -> list[str]:
        return list(self._tables)

    def liquid_props(self, fluid: str, temp_c: float,
                     override: Optional[FluidProperties] = None) -> FluidProperties:
        """Свойства жидкости при T. Приоритет — у значений из отчета HTRI."""
        if override is not None:
            return override
        table = self._tables[self.normalize_name(fluid)][0]
        return table.properties_at(fluid, temp_c, Phase.LIQUID)

    def vapor_props(self, fluid: str, temp_c: float) -> FluidProperties:
        table = self._tables[self.normalize_name(fluid)][1]
        return table.properties_at(f"{fluid} (пар)", temp_c, Phase.VAPOR)

    def mixture_props(self, fluid: str, temp_c: float, vapor_quality: float,
                      liquid_override: Optional[FluidProperties] = None
                      ) -> FluidProperties:
        """Свойства двухфазной смеси по массовому паросодержанию x.

        Гомогенная модель: для rho, mu, lambda — гармоническое смешение,
        для cp — массовое. При x=0 возвращаются свойства чистой жидкости,
        при x=1 — чистого пара.
        """
        x = min(1.0, max(0.0, vapor_quality))
        if x <= 1e-12:
            return self.liquid_props(fluid, temp_c, liquid_override)
        liq = self.liquid_props(fluid, temp_c, liquid_override)
        if x >= 1.0 - 1e-12:
            return self.vapor_props(fluid, temp_c)
        vap = self.vapor_props(fluid, temp_c)

        def harmonic(a: float, b: float) -> float:
            # (1-x)/a + x/b; a — жидкость, b — пар
            denom = (1 - x) / a + x / b
            return 1.0 / denom if denom > 0 else a

        return FluidProperties(
            name=f"{fluid} (смесь, x={x:.3f})",
            temperature_c=temp_c,
            density=harmonic(liq.density, vap.density),
            viscosity=harmonic(liq.viscosity, vap.viscosity),
            conductivity=harmonic(liq.conductivity, vap.conductivity),
            cp=(1 - x) * liq.cp + x * vap.cp,
            phase=Phase.TWO_PHASE,
            vapor_quality=x,
            latent_heat=vap.latent_heat,
        )
