"""Парсер PDF-отчетов HTRI (формы Т-1/Т-2/Т-3), раздел 2.1 ТЗ.

Основной метод — pdfplumber с координатным анализом слов (колонки
"Межтрубное пространство" / "Трубное пространство" различаются по
x-позиции); fallback — PyMuPDF. Отсутствующие поля помечаются в
ParsedInput.missing_fields ("требует ручного ввода").
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

from ..models import (
    Constraints,
    FluidProperties,
    ParsedInput,
    Phase,
    ShellGeometry,
    StreamData,
    TubeGeometry,
)

NUM_RE = re.compile(r"^\d+(?:[.,]\d+)?$")


def _to_float(token: str) -> float:
    return float(token.replace(",", "."))


def _is_num(token: str) -> bool:
    return bool(NUM_RE.match(token))


@dataclass
class _Word:
    text: str
    x0: float
    x1: float
    top: float

    @property
    def xc(self) -> float:
        return 0.5 * (self.x0 + self.x1)


class _ColumnMap:
    """Позиционная карта колонок: shell (вх./вых.) и tube (вх./вых.)."""

    def __init__(self, centers: list[float]):
        self.centers = sorted(centers)
        n = len(self.centers)
        if n >= 4:
            self.side_boundary = 0.5 * (self.centers[1] + self.centers[2])
            self.shell_io = 0.5 * (self.centers[0] + self.centers[1])
            self.tube_io = 0.5 * (self.centers[2] + self.centers[3])
        elif n == 2:
            self.side_boundary = 0.5 * (self.centers[0] + self.centers[1])
            self.shell_io = self.tube_io = None
        else:
            self.side_boundary = self.centers[0] if n == 1 else 0.0
            self.shell_io = self.tube_io = None

    def side(self, x: float) -> str:
        return "shell" if x < self.side_boundary else "tube"

    def inout(self, x: float, side: str) -> str:
        boundary = self.shell_io if side == "shell" else self.tube_io
        if boundary is None:
            return "in"
        return "in" if x < boundary else "out"


class HtriParser:
    """Извлечение данных из отчета HTRI в ParsedInput."""

    # Метки строк -> внутренние ключи
    ROW_LABELS = {
        "название среды": "fluid_names",
        "массовый расход": "mass_flow",
        "паровая фаза": "vapor_flow",
        "жидкость": "liquid_flow",
        "температура рабочая": "temperature",
        "плотность": "density",
        "вязкость": "viscosity",
        "теплоемкость": "cp",
        "теплопроводность": "conductivity",
        "скрытая теплота": "latent_heat",
        "рабочее давление на входе": "inlet_pressure",
        "скорость": "velocity",
        "потери давления": "pressure_drop",
        "коэффициент загрязнения": "fouling",
        "расчетное давление": "design_pressure",
        "расчетная температура": "design_temperature",
        "кол-во ходов": "passes",
    }

    def parse(self, path: str) -> ParsedInput:
        lines = self._extract_lines(path)
        result = ParsedInput(source_file=path)
        colmap = self._calibrate_columns(lines)
        rows = self._collect_rows(lines)
        self._fill_header(lines, result)
        self._fill_streams(rows, colmap, result)
        self.fill_fluid_names(lines, colmap, result)
        self._fill_geometry(lines, rows, colmap, result)
        self._fill_constraints(rows, colmap, result)
        self._fill_duty(lines, result)
        self._mark_missing(result)
        return result

    # ------------------------------------------------------------------
    # Извлечение слов и строк
    # ------------------------------------------------------------------
    @staticmethod
    def _extract_lines(path: str) -> list[list[_Word]]:
        words: list[_Word] = []
        try:
            import pdfplumber

            with pdfplumber.open(path) as pdf:
                for page in pdf.pages:
                    for w in page.extract_words():
                        words.append(_Word(w["text"], w["x0"], w["x1"], w["top"]))
        except Exception:
            words = []
        if not words:  # fallback: PyMuPDF
            import pymupdf

            with pymupdf.open(path) as doc:
                for page in doc:
                    for x0, top, x1, _, text, *_ in page.get_text("words"):
                        words.append(_Word(text, x0, x1, top))
        words.sort(key=lambda w: (round(w.top / 3.0), w.x0))
        lines: list[list[_Word]] = []
        current: list[_Word] = []
        last_top: Optional[float] = None
        for w in words:
            if last_top is None or abs(w.top - last_top) <= 3.0:
                current.append(w)
            else:
                lines.append(sorted(current, key=lambda v: v.x0))
                current = [w]
            last_top = w.top
        if current:
            lines.append(sorted(current, key=lambda v: v.x0))
        return lines

    @staticmethod
    def _line_text(line: list[_Word]) -> str:
        return " ".join(w.text for w in line)

    # ------------------------------------------------------------------
    # Калибровка колонок по строкам с 4 числами (плотность и т.п.)
    # ------------------------------------------------------------------
    def _calibrate_columns(self, lines: list[list[_Word]]) -> _ColumnMap:
        xs: list[float] = []
        for line in lines:
            text = self._line_text(line).lower()
            if any(text.startswith(k) for k in
                   ("плотность", "жидкость", "температура рабочая", "теплоемкость")):
                nums = [w for w in line if _is_num(w.text)]
                if len(nums) >= 2:
                    xs.extend(w.xc for w in nums)
        if not xs:
            return _ColumnMap([1e6])
        xs.sort()
        clusters: list[list[float]] = [[xs[0]]]
        for x in xs[1:]:
            if x - clusters[-1][-1] <= 25.0:
                clusters[-1].append(x)
            else:
                clusters.append([x])
        centers = [sum(c) / len(c) for c in clusters]
        # Ожидаем 4 колонки (shell вх/вых, tube вх/вых); при большем числе
        # кластеров (пары "пар/жидкость") берем медианы крайних групп
        if len(centers) > 4:
            centers = [centers[0], centers[1], centers[-2], centers[-1]]
        return _ColumnMap(centers)

    # ------------------------------------------------------------------
    # Сбор числовых значений по строкам-меткам
    # ------------------------------------------------------------------
    def _collect_rows(self, lines: list[list[_Word]]) -> dict[str, list[_Word]]:
        """{ключ: числовые токены (и '/') строки метки + до 2 следующих}."""
        rows: dict[str, list[_Word]] = {}
        label_idx: list[tuple[int, str]] = []
        for i, line in enumerate(lines):
            text = self._line_text(line).lower()
            for label, key in self.ROW_LABELS.items():
                if text.startswith(label):
                    label_idx.append((i, key))
                    break
        labeled_lines = {i for i, _ in label_idx}
        for i, key in label_idx:
            tokens: list[_Word] = []
            for j in range(i, min(i + 3, len(lines))):
                if j != i and j in labeled_lines:
                    break
                for w in lines[j]:
                    if _is_num(w.text) or w.text == "/":
                        tokens.append(w)
                if len([t for t in tokens if _is_num(t.text)]) >= 4:
                    break
            rows[key] = tokens
        return rows

    # ------------------------------------------------------------------
    @staticmethod
    def _split_pairs(tokens: list[_Word]) -> list[tuple[float, list[_Word]]]:
        """Числа с учетом пар 'пар / жидкость': возвращает [(x, [tokens])].

        Токены 'a / b' сливаются в одну группу [a, b], только если они
        близки по x (одна колонка); 'a / b' в разных колонках (например,
        "1760 / 2180" для shell/tube) остаются раздельными. Позиция
        группы — позиция первого токена; значение по умолчанию —
        последний токен группы (жидкость).
        """
        max_pair_gap = 60.0  # pt между числами пары внутри одной колонки
        merged: list[list[_Word]] = []
        i = 0
        while i < len(tokens):
            if tokens[i].text == "/":
                i += 1
                continue
            group = [tokens[i]]
            j = i + 1
            while (j + 1 < len(tokens) and tokens[j].text == "/"
                   and _is_num(tokens[j + 1].text)
                   and tokens[j + 1].x0 - group[-1].x1 < max_pair_gap):
                group.append(tokens[j + 1])
                j += 2
            merged.append(group)
            i = j
        return [(g[0].xc, g) for g in merged]

    # ------------------------------------------------------------------
    def _values_by_side(self, tokens: list[_Word], colmap: _ColumnMap,
                        prefer_liquid: bool = True
                        ) -> dict[str, list[tuple[str, float]]]:
        """{'shell': [('in', v), ('out', v)], 'tube': [...]}"""
        out: dict[str, list[tuple[str, float]]] = {"shell": [], "tube": []}
        for x, group in self._split_pairs(tokens):
            side = colmap.side(x)
            io = colmap.inout(x, side)
            value = _to_float(group[-1].text if prefer_liquid else group[0].text)
            out[side].append((io, value))
        return out

    @staticmethod
    def _pick(values: list[tuple[str, float]], io: str) -> Optional[float]:
        for tag, v in values:
            if tag == io:
                return v
        return None

    # ------------------------------------------------------------------
    # Заполнение модели
    # ------------------------------------------------------------------
    def _fill_header(self, lines: list[list[_Word]], result: ParsedInput) -> None:
        for line in lines:
            text = self._line_text(line)
            m = re.search(r"Позиция\s+(\S+)", text)
            if m and not result.position:
                result.position = m.group(1)
            m = re.search(r"Размер\s+(\d+)\s*[xх]\s*(\d+)", text)
            if m:
                result.shell_geometry = ShellGeometry(
                    inner_diameter=float(m.group(1)) / 1000.0)
            m = re.search(r"Поверхность,\s*м2\s+([\d,\.]+)", text)
            if m and result.surface_area is None:
                result.surface_area = _to_float(m.group(1))
            m = re.search(r"Ду\s+([\d,\.]+)", text)
            if m:
                result.shell_geometry.inner_diameter = _to_float(m.group(1)) / 1000.0

    def _fill_streams(self, rows: dict[str, list[_Word]], colmap: _ColumnMap,
                      result: ParsedInput) -> None:
        shell, tube = result.shell, result.tube
        # Названия сред — нечисловые слова: обрабатываются в fill_fluid_names
        for key in ("mass_flow", "vapor_flow", "liquid_flow", "temperature",
                    "density", "viscosity", "cp", "conductivity", "latent_heat",
                    "inlet_pressure", "velocity", "fouling"):
            tokens = rows.get(key)
            if not tokens:
                continue
            values = self._values_by_side(tokens, colmap)
            self._apply_row(key, values, shell, tube)

    def _apply_row(self, key: str, values: dict[str, list[tuple[str, float]]],
                   shell: StreamData, tube: StreamData) -> None:
        streams = {"shell": shell, "tube": tube}
        for side, stream in streams.items():
            vals = values[side]
            v_in = self._pick(vals, "in")
            v_out = self._pick(vals, "out")
            if v_in is None and vals:
                v_in = vals[0][1]
            if v_out is None and len(vals) > 1:
                v_out = vals[-1][1]

            if key == "mass_flow":
                if v_in is not None:
                    stream.mass_flow = v_in / 3600.0  # кг/ч -> кг/с
            elif key == "vapor_flow":
                stream.vapor_flow_in = v_in / 3600.0 if v_in is not None else None
                stream.vapor_flow_out = v_out / 3600.0 if v_out is not None else None
            elif key == "liquid_flow":
                stream.liquid_flow_in = v_in / 3600.0 if v_in is not None else None
                stream.liquid_flow_out = v_out / 3600.0 if v_out is not None else None
            elif key == "temperature":
                if v_in is not None:
                    stream.t_in = v_in
                if v_out is not None:
                    stream.t_out = v_out
            elif key == "inlet_pressure":
                if v_in is not None:
                    stream.inlet_pressure = v_in * 1000.0  # кПа -> Па
            else:
                self._apply_prop(key, stream, v_in, v_out)

    @staticmethod
    def _apply_prop(key: str, stream: StreamData, v_in: Optional[float],
                    v_out: Optional[float]) -> None:
        factors = {"density": 1.0, "viscosity": 1e-3, "cp": 1000.0,
                   "conductivity": 1.0, "latent_heat": 1000.0}
        if key == "fouling":
            return  # коэффициент загрязнения не используется ядром
        factor = factors.get(key, 1.0)
        for tag, val in (("in", v_in), ("out", v_out)):
            if val is None:
                continue
            props = stream.props_in if tag == "in" else stream.props_out
            if props is None:
                props = FluidProperties(name=stream.fluid_name,
                                        temperature_c=stream.t_in if tag == "in" else stream.t_out)
                if tag == "in":
                    stream.props_in = props
                else:
                    stream.props_out = props
            if key == "density":
                props.density = val
            elif key == "viscosity":
                props.viscosity = val * factor
            elif key == "cp":
                props.cp = val * factor
            elif key == "conductivity":
                props.conductivity = val
            elif key == "latent_heat":
                props.latent_heat = val * factor

    def _fill_geometry(self, lines: list[list[_Word]], rows: dict[str, list[_Word]],
                       colmap: _ColumnMap, result: ParsedInput) -> None:
        geom = result.tube_geometry
        for line in lines:
            text = self._line_text(line)
            if "Кол-во труб" in text:
                m = re.search(r"Кол-во труб\s*:?\s*(\d+)", text)
                if m:
                    geom.n_tubes = int(m.group(1))
                for label, attr, factor in (
                        (r"Диаметр\s+([\d,\.]+)", "outer_diameter", 1e-3),
                        (r"Толщина\s+([\d,\.]+)", "wall_thickness", 1e-3),
                        (r"Длина\s+([\d,\.]+)", "length", 1.0),
                        (r"Шаг\s+([\d,\.]+)", "layout_pitch", 1e-3)):
                    m = re.search(label, text)
                    if m:
                        setattr(geom, attr, _to_float(m.group(1)) * factor)
            m = re.search(r"Угол\s+(\d+(?:[.,]\d+)?)", text)
            if m:
                geom.twist_angle = _to_float(m.group(1))
        passes = rows.get("passes")
        if passes:
            nums = [_to_float(t.text) for t in passes if _is_num(t.text)]
            if nums:
                geom.n_passes = int(nums[-1])

    def _fill_constraints(self, rows: dict[str, list[_Word]], colmap: _ColumnMap,
                          result: ParsedInput) -> None:
        cons = result.constraints
        tokens = rows.get("pressure_drop")
        if tokens:
            values = self._values_by_side(tokens, colmap, prefer_liquid=False)
            # Для "Потери давления (макс./расч.)" пары: in=max, out=расч.
            sh, tb = values["shell"], values["tube"]
            if sh:
                cons.dp_shell_max = sh[0][1] * 1000.0
                if len(sh) > 1:
                    result.dp_shell_calc = sh[1][1] * 1000.0
            if tb:
                cons.dp_tube_max = tb[0][1] * 1000.0
                if len(tb) > 1:
                    result.dp_tube_calc = tb[1][1] * 1000.0
        # Блок "Расчетные параметры" имеет собственные 2 колонки
        # (Межтрубное/Трубное), не совпадающие с колонками блока
        # "Режим работы": значения берем по порядку слева направо.
        tokens = rows.get("design_pressure")
        if tokens:
            nums = sorted((t for t in tokens if _is_num(t.text)), key=lambda t: t.x0)
            if nums:
                cons.p_design_shell = _to_float(nums[0].text) * 1000.0
            if len(nums) > 1:
                cons.p_design_tube = _to_float(nums[1].text) * 1000.0
        tokens = rows.get("design_temperature")
        if tokens:
            nums = sorted((t for t in tokens if _is_num(t.text)), key=lambda t: t.x0)
            if nums:
                cons.t_design_shell = _to_float(nums[0].text)
            if len(nums) > 1:
                cons.t_design_tube = _to_float(nums[1].text)

    def _fill_duty(self, lines: list[list[_Word]], result: ParsedInput) -> None:
        for line in lines:
            text = self._line_text(line)
            m = re.search(r"Тепловая мощность\s+([\d\s,\.]+?)\s*кВт", text)
            if m and result.heat_duty is None:
                result.heat_duty = _to_float(m.group(1).replace(" ", "")) * 1000.0
            m = re.search(r"MTD\s+([\d,\.]+)", text)
            if m and result.mtd is None:
                result.mtd = _to_float(m.group(1))

    def fill_fluid_names(self, lines: list[list[_Word]], colmap: _ColumnMap,
                         result: ParsedInput) -> None:
        """Названия сред по колонкам (нечисловые слова строки метки)."""
        for line in lines:
            text = self._line_text(line).lower()
            if text.startswith("название среды"):
                shell_words, tube_words = [], []
                for w in line:
                    if w.text.lower() in ("название", "среды"):
                        continue
                    (shell_words if colmap.side(w.xc) == "shell" else tube_words).append(w.text)
                result.shell.fluid_name = " ".join(shell_words)
                result.tube.fluid_name = " ".join(tube_words)
                return

    def _mark_missing(self, result: ParsedInput) -> None:
        missing = result.missing_fields
        checks = [
            (result.position, "Позиция"),
            (result.shell.fluid_name, "Название среды (межтрубное)"),
            (result.tube.fluid_name, "Название среды (трубное)"),
            (result.shell.mass_flow, "Массовый расход (межтрубное)"),
            (result.tube.mass_flow, "Массовый расход (трубное)"),
            (result.constraints.dp_shell_max, "Потери давления макс. (межтрубное)"),
            (result.constraints.dp_tube_max, "Потери давления макс. (трубное)"),
            (result.surface_area, "Поверхность теплообмена"),
        ]
        for value, label in checks:
            if not value:
                missing.append(label)


def parse_htri_pdf(path: str) -> ParsedInput:
    """Точка входа: распарсить отчет HTRI (Т-1/Т-2/Т-3) в ParsedInput."""
    return HtriParser().parse(path)
