"""Двухфазный режим: поправки для смеси жидкость+пар.

Статья Yang et al. (2011) двухфазный поток не охватывает, поэтому
однофазные корреляции витой трубы применяются к свойствам смеси
(гомогенная модель) либо с двухфазным множителем Локхарта-Мартинелли
(решение заказчика, PLAN.md п. 3).
"""
from __future__ import annotations


def harmonic_mix(a: float, b: float, x: float) -> float:
    """Гармоническое смешение: 1/y = (1-x)/a + x/b."""
    if x <= 1e-12:
        return a
    if x >= 1.0 - 1e-12:
        return b
    denom = (1 - x) / a + x / b
    return 1.0 / denom if denom > 0 else a


def lockhart_martinelli_X_tt(vapor_quality: float, rho_l: float, rho_v: float,
                             mu_l: float, mu_v: float) -> float:
    """Параметр Локхарта-Мартинелли для турбулентно-турбулентного режима."""
    x = min(max(vapor_quality, 1e-9), 1.0 - 1e-9)
    return ((1 - x) / x) ** 0.9 * (rho_v / rho_l) ** 0.5 * (mu_l / mu_v) ** 0.1


def lm_pressure_multiplier_liquid(vapor_quality: float, rho_l: float,
                                  rho_v: float, mu_l: float, mu_v: float,
                                  c: float = 20.0) -> float:
    """Двухфазный множитель давления по жидкой фазе Phi_l^2.

    Phi_l^2 = 1 + C/X_tt + 1/X_tt^2;  C=20 (турбулентная жидкость —
    турбулентный пар). dP_tp = Phi_l^2 * dP_liquid_only.
    """
    x = vapor_quality
    if x <= 1e-12:
        return 1.0
    x_tt = lockhart_martinelli_X_tt(x, rho_l, rho_v, mu_l, mu_v)
    return 1.0 + c / x_tt + 1.0 / x_tt**2
