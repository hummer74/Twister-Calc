"""Корреляции Nu и f для витых эллиптических труб.

Турбулентный режим (Re ~ 6000...50000, вода):
    Yang S., Zhang L., Xu H. "Experimental study on convective heat
    transfer and flow resistance characteristics of water flow in
    twisted elliptical tubes", Applied Thermal Engineering, 2011.
    DOI: 10.1016/j.applthermaleng.2011.05.030

Ламинарный режим (Re < 2300):
    Базовые корреляции гладкой трубы (Зидер-Тейт для Nu, 64/Re для f,
    Дарси) с поправочными множителями на геометрию витой эллиптической
    трубы.
    TODO: заменить множители на корреляции Yang et al. для ламинарного
    режима, когда первоисточник будет предоставлен заказчиком.

Переходная зона (Re ~ 2300...6000): лог-линейная интерполяция между
ламинарной и турбулентной корреляциями + предупреждение.
"""
from __future__ import annotations

import math
from abc import ABC, abstractmethod

from ..models import FlowRegime, TubeGeometry

RE_LAMINAR_MAX = 2300.0
RE_TURBULENT_MIN = 6000.0
RE_TURBULENT_MAX = 50000.0


class CorrelationModel(ABC):
    """Интерфейс корреляционной модели (Nu, f) для витой трубы."""

    name: str = ""

    @abstractmethod
    def nusselt(self, re: float, pr: float, geom: TubeGeometry) -> float:
        ...

    @abstractmethod
    def friction(self, re: float, geom: TubeGeometry) -> float:
        """Коэффициент трения Дарси."""
        ...


def _twist_terms(geom: TubeGeometry) -> tuple[float, float, float]:
    ratio = geom.axis_ratio
    s_over_de = geom.twist_pitch / geom.equivalent_diameter
    return ratio, s_over_de, geom.equivalent_diameter


class TurbulentYang2011(CorrelationModel):
    """Турбулентные корреляции Yang et al. (2011)."""

    name = "Yang et al. (2011), турбулентный режим"

    def nusselt(self, re: float, pr: float, geom: TubeGeometry) -> float:
        ratio, s_over_de, _ = _twist_terms(geom)
        correction = 1.0 + 3.54 * ratio**0.357 * s_over_de**-0.55
        return 0.023 * re**0.8 * pr**0.4 * correction

    def friction(self, re: float, geom: TubeGeometry) -> float:
        ratio, s_over_de, _ = _twist_terms(geom)
        correction = 1.0 + 2.08 * ratio**0.89 * s_over_de**-0.63
        return 0.3164 * re**-0.25 * correction


class LaminarTwistedTube(CorrelationModel):
    """Ламинарные корреляции: гладкая труба + множитель витой геометрии.

    TODO: коэффициенты множителей ориентировочные (порядок величины по
    литературным данным для витых эллиптических труб); заменить на
    корреляции Yang et al. для ламинарного режима при получении
    первоисточника.
    """

    name = "Ламинарный режим (Зидер-Тейт x множитель витой трубы)"

    def nusselt(self, re: float, pr: float, geom: TubeGeometry) -> float:
        ratio, s_over_de, d_e = _twist_terms(geom)
        gz = max(re * pr * d_e / geom.length, 1e-9)
        nu_smooth = 1.86 * gz ** (1.0 / 3.0)
        correction = 1.0 + 2.1 * ratio**0.29 * s_over_de**-0.4
        return nu_smooth * correction

    def friction(self, re: float, geom: TubeGeometry) -> float:
        ratio, s_over_de, _ = _twist_terms(geom)
        correction = 1.0 + 1.15 * ratio**0.55 * s_over_de**-0.5
        return 64.0 / max(re, 1e-9) * correction


def smooth_tube_nusselt(re: float, pr: float) -> float:
    """Nu0 для гладкой круглой трубы (база для PEC), Yang et al. (2011)."""
    return 0.023 * re**0.8 * pr**0.4


def smooth_tube_friction(re: float) -> float:
    """f0 для гладкой круглой трубы (Дарси), Yang et al. (2011)."""
    return 0.3164 * re**-0.25


class CorrelationSelector:
    """Выбор корреляции по числу Рейнольдса с контролем области валидности."""

    def __init__(self,
                 laminar: CorrelationModel | None = None,
                 turbulent: CorrelationModel | None = None):
        self.laminar = laminar or LaminarTwistedTube()
        self.turbulent = turbulent or TurbulentYang2011()

    @staticmethod
    def regime(re: float) -> FlowRegime:
        if re < RE_LAMINAR_MAX:
            return FlowRegime.LAMINAR
        if re < RE_TURBULENT_MIN:
            return FlowRegime.TRANSITION
        return FlowRegime.TURBULENT

    def nusselt(self, re: float, pr: float, geom: TubeGeometry) -> tuple[float, FlowRegime, list[str]]:
        return self._select(re, pr, geom, "nu")

    def friction(self, re: float, pr: float, geom: TubeGeometry) -> tuple[float, FlowRegime, list[str]]:
        return self._select(re, pr, geom, "f")

    def _select(self, re: float, pr: float, geom: TubeGeometry,
                kind: str) -> tuple[float, FlowRegime, list[str]]:
        warnings: list[str] = []
        regime = self.regime(re)

        def lam() -> float:
            return (self.laminar.nusselt if kind == "nu" else self.laminar.friction)(
                *(((re, pr, geom)) if kind == "nu" else (re, geom)))

        def turb() -> float:
            return (self.turbulent.nusselt if kind == "nu" else self.turbulent.friction)(
                *((re, pr, geom) if kind == "nu" else (re, geom)))

        if regime is FlowRegime.LAMINAR:
            return lam(), regime, warnings
        if regime is FlowRegime.TURBULENT:
            if re > RE_TURBULENT_MAX:
                warnings.append(
                    f"Re={re:.0f} выше области валидности корреляций Yang et al. "
                    f"(Re <= {RE_TURBULENT_MAX:.0f}); результат — экстраполяция.")
            return turb(), regime, warnings

        # Переходная зона: лог-линейная интерполяция между режимами
        warnings.append(
            f"Re={re:.0f} в переходной зоне ({RE_LAMINAR_MAX:.0f}..."
            f"{RE_TURBULENT_MIN:.0f}); значение интерполировано, "
            "точность снижена.")
        w = (math.log(re) - math.log(RE_LAMINAR_MAX)) / (
            math.log(RE_TURBULENT_MIN) - math.log(RE_LAMINAR_MAX))
        v_lam, v_turb = max(lam(), 1e-12), max(turb(), 1e-12)
        value = math.exp((1 - w) * math.log(v_lam) + w * math.log(v_turb))
        return value, regime, warnings
