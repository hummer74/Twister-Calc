"""Гидравлические расчеты: скорость, Re, перепад давления."""
from __future__ import annotations


def velocity(mass_flow: float, density: float, flow_area: float) -> float:
    """Средняя скорость потока, м/с."""
    if density <= 0 or flow_area <= 0:
        raise ValueError("Плотность и проходное сечение должны быть положительными")
    return mass_flow / (density * flow_area)


def reynolds(density: float, vel: float, d_e: float, viscosity: float) -> float:
    """Re = rho*u*d_e/mu."""
    if viscosity <= 0:
        raise ValueError("Вязкость должна быть положительной")
    return density * vel * d_e / viscosity


def pressure_drop(friction_factor: float, length: float, d_e: float,
                  density: float, vel: float) -> float:
    """Перепад давления по Дарси-Вейсбаха: dP = f*(L/d_e)*rho*u^2/2, Па."""
    if d_e <= 0:
        raise ValueError("Эквивалентный диаметр должен быть положительным")
    return friction_factor * (length / d_e) * density * vel**2 / 2.0


def mass_velocity(mass_flow: float, flow_area: float) -> float:
    """Массовая скорость G, кг/(м2·с)."""
    if flow_area <= 0:
        raise ValueError("Проходное сечение должно быть положительным")
    return mass_flow / flow_area
