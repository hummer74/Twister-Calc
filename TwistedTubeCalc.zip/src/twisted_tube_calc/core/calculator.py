"""Фасад расчетного ядра (раздел 2.2 ТЗ).

Выполняет теплогидравлический расчет аппарата: Re, Pr, Nu, h, f, dP
для трубного пространства (витая эллиптическая труба), тепловой баланс,
LMTD, общий коэффициент теплопередачи U, критерии Pf и PEC.
Поддерживает однофазный и двухфазный (жидкость+пар) режимы.
"""
from __future__ import annotations

from typing import Optional

from ..fluids import FluidModel
from ..models import (
    CalcResult,
    FlowRegime,
    FluidProperties,
    ParsedInput,
    Phase,
    SideResult,
    StreamData,
    TubeGeometry,
)
from . import hydraulics, thermal
from .correlations import CorrelationSelector, smooth_tube_friction, smooth_tube_nusselt
from .two_phase import lm_pressure_multiplier_liquid

TWO_PHASE_METHODS = ("homogeneous", "lockhart-martinelli")


class HeatExchangerCalculator:
    def __init__(self,
                 fluid_model: Optional[FluidModel] = None,
                 selector: Optional[CorrelationSelector] = None,
                 two_phase_method: str = "homogeneous"):
        if two_phase_method not in TWO_PHASE_METHODS:
            raise ValueError(f"Неизвестный двухфазный метод: {two_phase_method}")
        self.fluids = fluid_model or FluidModel()
        self.selector = selector or CorrelationSelector()
        self.two_phase_method = two_phase_method

    # ------------------------------------------------------------------
    def resolve_stream_props(self, stream: StreamData) -> tuple[FluidProperties, float]:
        """Средние свойства потока и среднее паросодержание.

        Приоритет: значения, спарсенные из отчета HTRI (props_in/out),
        затем справочные таблицы. Для двухфазного потока — свойства
        смеси по среднему паросодержанию.
        """
        parsed = stream.mean_props
        x_in, x_out = stream.vapor_quality_in, stream.vapor_quality_out
        x_mean = 0.0
        if x_in is not None or x_out is not None:
            x_mean = 0.5 * ((x_in or 0.0) + (x_out or 0.0))

        if x_mean > 1e-12:
            # Двухфазный поток: спарсенные свойства трактуем как свойства
            # жидкой фазы (в отчетах HTRI приведены пары пар/жидкость).
            return self.fluids.mixture_props(
                stream.fluid_name, stream.t_mean, x_mean,
                liquid_override=parsed), x_mean
        if parsed is not None:
            return parsed, 0.0
        return self.fluids.liquid_props(stream.fluid_name, stream.t_mean), 0.0

    # ------------------------------------------------------------------
    def compute_tube_side(self, stream: StreamData,
                          geom: TubeGeometry) -> SideResult:
        """Полный расчет трубного пространства для заданной геометрии."""
        props, x_mean = self.resolve_stream_props(stream)
        two_phase = x_mean > 1e-12 or props.phase is Phase.TWO_PHASE

        flow_area = geom.flow_area_total
        d_e = geom.equivalent_diameter
        path_length = geom.length * max(1, geom.n_passes)
        warnings: list[str] = []

        vel = hydraulics.velocity(stream.mass_flow, props.density, flow_area)
        re = hydraulics.reynolds(props.density, vel, d_e, props.viscosity)
        pr = props.prandtl

        nu, regime, w = self.selector.nusselt(re, pr, geom)
        warnings.extend(w)
        f, _, w = self.selector.friction(re, pr, geom)
        warnings.extend(w)
        h = thermal.h_from_nusselt(nu, props.conductivity, d_e)

        if two_phase and self.two_phase_method == "lockhart-martinelli":
            dp = self._dp_two_phase_lm(stream, geom, props, x_mean, path_length)
        else:
            dp = hydraulics.pressure_drop(f, path_length, d_e, props.density, vel)

        if two_phase:
            warnings.append(
                f"Двухфазный режим (x={x_mean:.3f}), метод: {self.two_phase_method}. "
                "Корреляции Yang et al. применены к свойствам смеси.")

        return SideResult(
            regime=regime, velocity=vel, reynolds=re, prandtl=pr, nusselt=nu,
            h=h, friction_factor=f, dp=dp, two_phase=two_phase,
            vapor_quality=x_mean, warnings=warnings)

    def _dp_two_phase_lm(self, stream: StreamData, geom: TubeGeometry,
                         mixture: FluidProperties, x: float,
                         path_length: float) -> float:
        """dP по Локхарту-Мартинелли: dP_tp = Phi_l^2 * dP_liquid_only."""
        liq = self.fluids.liquid_props(stream.fluid_name, stream.t_mean,
                                       override=stream.mean_props)
        vap = self.fluids.vapor_props(stream.fluid_name, stream.t_mean)
        flow_area = geom.flow_area_total
        d_e = geom.equivalent_diameter
        # Режим "весь поток жидкий"
        vel_lo = hydraulics.velocity(stream.mass_flow, liq.density, flow_area)
        re_lo = hydraulics.reynolds(liq.density, vel_lo, d_e, liq.viscosity)
        f_lo, _, _ = self.selector.friction(re_lo, liq.prandtl, geom)
        dp_lo = hydraulics.pressure_drop(f_lo, path_length, d_e, liq.density, vel_lo)
        phi_l2 = lm_pressure_multiplier_liquid(
            x, liq.density, vap.density, liq.viscosity, vap.viscosity)
        return dp_lo * phi_l2

    # ------------------------------------------------------------------
    def calculate(self, inp: ParsedInput,
                  geom: Optional[TubeGeometry] = None) -> CalcResult:
        """Сводный расчет аппарата (раздел 2.2 ТЗ)."""
        geom = geom or inp.tube_geometry
        result = CalcResult()
        warnings: list[str] = []

        result.tube = self.compute_tube_side(inp.tube, geom)

        # Межтрубное пространство: гидравлика пучка витых труб не
        # охватывается корреляциями Yang et al. — используем расчетные
        # значения HTRI из отчета (при наличии).
        shell = SideResult()
        if inp.dp_shell_calc is not None:
            shell.dp = inp.dp_shell_calc
            shell.warnings.append(
                "dP межтрубного пространства принято по отчету HTRI "
                "(гидравлика пучка не моделируется).")
        result.shell = shell

        # Тепловой баланс
        hot, cold = (inp.shell, inp.tube) if inp.shell.t_in >= inp.tube.t_in \
            else (inp.tube, inp.shell)
        q_hot = self._stream_duty(hot)
        q_cold = self._stream_duty(cold)
        result.heat_duty = 0.5 * (q_hot + q_cold)

        try:
            result.lmtd = thermal.lmtd_countercurrent(
                hot.t_in, hot.t_out, cold.t_in, cold.t_out)
        except ValueError as exc:
            if inp.mtd:
                result.lmtd = inp.mtd
                warnings.append(
                    f"LMTD не вычисляется ({exc}); принят MTD={inp.mtd} из отчета HTRI.")
            else:
                warnings.append(f"LMTD не вычисляется ({exc}).")
                result.lmtd = 0.0

        area = inp.surface_area or geom.heat_transfer_area
        if result.lmtd > 0 and area > 0:
            result.u_value = thermal.overall_u(q_hot, q_cold, area, result.lmtd)

        # Критерии эффективности (база — гладкая круглая труба при том же Re)
        t = result.tube
        if t.reynolds > 0 and t.prandtl > 0:
            nu0 = smooth_tube_nusselt(t.reynolds, t.prandtl)
            f0 = smooth_tube_friction(t.reynolds)
            if t.nusselt > 0 and t.friction_factor > 0:
                result.pec = (t.nusselt / nu0) / (t.friction_factor / f0) ** (1.0 / 3.0)
            if t.h > 0 and t.dp > 0:
                d_e = geom.equivalent_diameter
                props, _ = self.resolve_stream_props(inp.tube)
                h0 = thermal.h_from_nusselt(nu0, props.conductivity, d_e)
                path_length = geom.length * max(1, geom.n_passes)
                dp0 = hydraulics.pressure_drop(f0, path_length, d_e,
                                               props.density, t.velocity)
                if h0 > 0 and dp0 > 0:
                    result.pf = (t.h / h0) / (t.dp / dp0)

        if result.tube.regime is FlowRegime.TURBULENT and t.reynolds > 50000:
            warnings.append("Re выше области валидности корреляций Yang et al. (2011).")
        result.warnings = warnings
        return result

    # ------------------------------------------------------------------
    def _stream_duty(self, stream: StreamData) -> float:
        props = stream.mean_props
        cp = props.cp if props else 2200.0
        latent = props.latent_heat if props else None
        if latent is None and stream.vapor_flow_in is not None:
            # Паросодержание задано, но скрытая теплота не спарсена —
            # берем из справочной таблицы паровой фазы
            latent = self.fluids.vapor_props(stream.fluid_name,
                                             stream.t_mean).latent_heat
        return thermal.heat_duty_with_phase_change(
            stream.mass_flow, cp, stream.t_in, stream.t_out,
            stream.vapor_flow_in, stream.vapor_flow_out, latent)
