"""Тепловые расчеты: LMTD, коэффициент теплопередачи, тепловая мощность."""
from __future__ import annotations

import math


def lmtd_countercurrent(t_hot_in: float, t_hot_out: float,
                        t_cold_in: float, t_cold_out: float) -> float:
    """Среднелогарифмический температурный напор (противоток)."""
    dt1 = t_hot_in - t_cold_out
    dt2 = t_hot_out - t_cold_in
    return lmtd(dt1, dt2)


def lmtd(dt1: float, dt2: float) -> float:
    """LMTD по двум концевым температурным напорам."""
    if dt1 <= 0 or dt2 <= 0:
        raise ValueError(
            f"Температурные напоры должны быть положительными (dt1={dt1}, dt2={dt2})")
    if abs(dt1 - dt2) < 1e-9:
        return dt1
    return (dt1 - dt2) / math.log(dt1 / dt2)


def heat_duty_sensible(mass_flow: float, cp: float, t_in: float, t_out: float) -> float:
    """Тепловая мощность без фазового перехода, Вт (по модулю)."""
    return abs(mass_flow * cp * (t_in - t_out))


def heat_duty_with_phase_change(mass_flow: float, cp: float, t_in: float,
                                t_out: float, vapor_flow_in: float | None,
                                vapor_flow_out: float | None,
                                latent_heat: float | None) -> float:
    """Тепловая мощность с учетом изменения паросодержания, Вт (по модулю)."""
    q = heat_duty_sensible(mass_flow, cp, t_in, t_out)
    if (vapor_flow_in is not None and vapor_flow_out is not None
            and latent_heat is not None):
        q += abs((vapor_flow_out - vapor_flow_in) * latent_heat)
    return q


def overall_u(q_hot: float, q_cold: float, area: float, lmtd_value: float) -> float:
    """Общий коэффициент теплопередачи по ТЗ: U = (Qh+Qc)/(2*A*dTlm)."""
    if area <= 0 or lmtd_value <= 0:
        raise ValueError("Площадь и LMTD должны быть положительными")
    return (q_hot + q_cold) / (2.0 * area * lmtd_value)


def h_from_nusselt(nu: float, conductivity: float, d_e: float) -> float:
    """Коэффициент теплоотдачи h = Nu*lambda/d_e, Вт/(м2·К)."""
    if d_e <= 0:
        raise ValueError("Эквивалентный диаметр должен быть положительным")
    return nu * conductivity / d_e
