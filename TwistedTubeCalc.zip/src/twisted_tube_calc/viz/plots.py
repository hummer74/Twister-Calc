"""Графики Matplotlib для встраивания в GUI и экспорта в PDF (п. 2.4 ТЗ)."""
from __future__ import annotations

import dataclasses

import matplotlib

matplotlib.use("Agg")  # рендер без дисплея; GUI переключает backend сам
import numpy as np
from matplotlib.figure import Figure

from ..core import HeatExchangerCalculator
from ..models import ParsedInput, TubeGeometry

matplotlib.rcParams["font.family"] = "DejaVu Sans"


def reynolds_vs_flow(inp: ParsedInput, calculator: HeatExchangerCalculator,
                     geom: TubeGeometry | None = None,
                     flow_factors: np.ndarray | None = None) -> Figure:
    """Зависимость числа Рейнольдса от массового расхода."""
    geom = geom or inp.tube_geometry
    factors = flow_factors if flow_factors is not None else np.linspace(0.3, 1.5, 25)
    base_flow = inp.tube.mass_flow
    res_list = []
    for k in factors:
        variant = dataclasses.replace(inp)
        variant.tube = dataclasses.replace(inp.tube, mass_flow=base_flow * k)
        res_list.append(calculator.calculate(variant, geom=geom).tube)

    fig = Figure(figsize=(6, 4), dpi=100)
    ax = fig.add_subplot(111)
    ax.plot([k * base_flow * 3600 for k in factors],
            [r.reynolds for r in res_list], "b-o", markersize=4)
    ax.axhspan(2300, 6000, color="orange", alpha=0.15, label="Переходная зона")
    ax.set_xlabel("Массовый расход, кг/ч")
    ax.set_ylabel("Re")
    ax.set_title("Число Рейнольдса от расхода (трубное пространство)")
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    return fig


def dp_vs_flow(inp: ParsedInput, calculator: HeatExchangerCalculator,
               geom: TubeGeometry | None = None,
               flow_factors: np.ndarray | None = None) -> Figure:
    """Зависимость перепада давления от массового расхода."""
    geom = geom or inp.tube_geometry
    factors = flow_factors if flow_factors is not None else np.linspace(0.3, 1.5, 25)
    base_flow = inp.tube.mass_flow
    dps = []
    for k in factors:
        variant = dataclasses.replace(inp)
        variant.tube = dataclasses.replace(inp.tube, mass_flow=base_flow * k)
        dps.append(calculator.calculate(variant, geom=geom).tube.dp / 1000.0)

    fig = Figure(figsize=(6, 4), dpi=100)
    ax = fig.add_subplot(111)
    ax.plot([k * base_flow * 3600 for k in factors], dps, "r-s", markersize=4,
            label="ΔP расчетное")
    if inp.constraints.dp_tube_max:
        ax.axhline(inp.constraints.dp_tube_max / 1000.0, color="k", linestyle="--",
                   label="ΔP макс. допустимое")
    ax.set_xlabel("Массовый расход, кг/ч")
    ax.set_ylabel("ΔP, кПа")
    ax.set_title("Перепад давления от расхода (трубное пространство)")
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    return fig


def efficiency_curves(inp: ParsedInput, calculator: HeatExchangerCalculator,
                      param: str = "twist_pitch",
                      values: np.ndarray | None = None) -> Figure:
    """Кривые тепловой эффективности Pf и PEC от параметра геометрии."""
    geom0 = inp.tube_geometry
    if param == "twist_pitch":
        values = values if values is not None else np.linspace(0.1, 1.0, 15)
        label = "Шаг скрутки S, м"
    else:
        values = values if values is not None else np.linspace(1.2, 3.0, 15)
        label = "Соотношение осей a/b"

    pfs, pecs = [], []
    for v in values:
        geom = dataclasses.replace(geom0, **{param: float(v)})
        res = calculator.calculate(inp, geom=geom)
        pfs.append(res.pf)
        pecs.append(res.pec)

    fig = Figure(figsize=(6, 4), dpi=100)
    ax = fig.add_subplot(111)
    ax.plot(values, pfs, "g-^", markersize=4, label="Pf (ТЗ)")
    ax.plot(values, pecs, "m-v", markersize=4, label="PEC (Yang et al.)")
    ax.set_xlabel(label)
    ax.set_ylabel("Критерий эффективности")
    ax.set_title("Кривые тепловой эффективности")
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    return fig
