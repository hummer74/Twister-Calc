"""Генератор "умной" пояснительной записки (п. 2.4 ТЗ)."""
from __future__ import annotations

from ..core.correlations import (
    RE_TURBULENT_MAX,
    RE_TURBULENT_MIN,
    smooth_tube_friction,
    smooth_tube_nusselt,
)
from ..models import CalcResult, OptimizationResult, ParsedInput


def generate_report_text(inp: ParsedInput, calc: CalcResult,
                         opt: OptimizationResult | None = None) -> str:
    """Автоматическая пояснительная записка по шаблону ТЗ."""
    lines: list[str] = []
    tube = calc.tube
    geom = opt_geom = inp.tube_geometry

    lines.append("ПОЯСНИТЕЛЬНАЯ ЗАПИСКА")
    lines.append("=" * 60)
    pos = inp.position or "—"
    lines.append(f"Аппарат: позиция {pos}")
    lines.append(f"Среды: межтрубное пространство — {inp.shell.fluid_name or '—'}; "
                 f"трубное пространство — {inp.tube.fluid_name or '—'}.")
    lines.append("")

    nu0 = smooth_tube_nusselt(tube.reynolds, tube.prandtl) if tube.reynolds else 0.0
    f0 = smooth_tube_friction(tube.reynolds) if tube.reynolds else 0.0
    h_gain = (tube.nusselt / nu0 - 1.0) * 100.0 if nu0 else 0.0
    f_gain = (tube.friction_factor / f0 - 1.0) * 100.0 if f0 else 0.0
    dp_limit = inp.constraints.dp_tube_max

    regime_ru = {"laminar": "ламинарный", "transition": "переходный",
                 "turbulentный": "турбулентный", "turbulent": "турбулентный"}[tube.regime.value]
    lines.append(
        f"Применение витой трубы со скруткой s = {geom.twist_pitch * 1000:.0f} мм "
        f"(соотношение осей a/b = {geom.axis_ratio:.2f}) локально увеличивает "
        f"турбулентность потока, что повышает коэффициент теплоотдачи на "
        f"{h_gain:.0f} % по сравнению с гладкой трубой, однако увеличивает "
        f"гидравлические потери на {tube.dp / 1000:.1f} кПа"
        + (f", оставаясь в пределах допустимого лимита "
           f"{dp_limit / 1000:.1f} кПа." if dp_limit and tube.dp <= dp_limit
           else "."))
    if dp_limit and tube.dp > dp_limit:
        lines.append(
            f"ВНИМАНИЕ: потери давления {tube.dp / 1000:.1f} кПа превышают "
            f"допустимый лимит {dp_limit / 1000:.1f} кПа!")
    lines.append("")
    lines.append(f"Режим течения в трубах: {regime_ru} (Re = {tube.reynolds:.0f}).")
    if tube.regime.value == "transition":
        lines.append(f"Переходная зона ({2300}...{RE_TURBULENT_MIN:.0f}): "
                     "точность корреляций снижена.")
    if tube.reynolds > RE_TURBULENT_MAX:
        lines.append(f"Re выше области валидности корреляций Yang et al. "
                     f"({RE_TURBULENT_MAX:.0f}): результат — экстраполяция.")
    if tube.two_phase:
        lines.append(f"Поток двухфазный: среднее паросодержание x = "
                     f"{tube.vapor_quality:.3f}; корреляции применены к "
                     "свойствам смеси.")
    lines.append(f"Критерии эффективности: Pf = {calc.pf:.3f} (по ТЗ), "
                 f"PEC = {calc.pec:.3f} (Yang et al., 2011).")
    lines.append(f"Коэффициент теплопередачи U = {calc.u_value:.1f} Вт/(м2·К), "
                 f"LMTD = {calc.lmtd:.1f} °C, тепловая мощность "
                 f"Q = {calc.heat_duty / 1000:.0f} кВт.")

    if opt and opt.success:
        lines.append("")
        lines.append("РЕЗУЛЬТАТ ОПТИМИЗАЦИИ")
        lines.append(f"Подобранная геометрия: a/b = {opt.best_axis_ratio:.2f}, "
                     f"шаг скрутки S = {opt.best_twist_pitch * 1000:.0f} мм.")
        lines.append(f"Достигнуты: h = {opt.best_h:.0f} Вт/(м2·К), "
                     f"ΔP = {opt.best_dp_tube / 1000:.1f} кПа, "
                     f"Pf = {opt.pf:.3f}, PEC = {opt.pec:.3f}.")
    for w in calc.warnings:
        lines.append(f"Предупреждение: {w}")
    return "\n".join(lines)
