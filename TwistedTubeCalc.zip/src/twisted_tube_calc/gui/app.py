"""Графический интерфейс приложения (CustomTkinter), раздел 2 ТЗ.

Вкладки: «Исходные данные» (загрузка PDF, интерактивная таблица с
ручной корректировкой), «Расчёт», «Оптимизация», «Графики», «Экспорт».
"""
from __future__ import annotations

import threading
import tkinter as tk
from tkinter import filedialog, messagebox

import customtkinter as ctk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

from ..core import TWO_PHASE_METHODS, HeatExchangerCalculator
from ..exporters import export_pdf, export_xlsx, load_session, save_session
from ..models import (
    CalcResult,
    FluidProperties,
    OptimizationResult,
    ParsedInput,
    SessionSnapshot,
    StreamData,
)
from ..optimizer import GeometryOptimizer
from ..parsers import parse_htri_pdf
from ..viz import dp_vs_flow, efficiency_curves, generate_report_text, reynolds_vs_flow

# Поля таблицы исходных данных: (метка, сторона, атрибут StreamData, масштаб)
STREAM_FIELDS = [
    ("Название среды", "fluid_name", 1.0),
    ("Массовый расход, кг/ч", "mass_flow", 3600.0),
    ("Температура вход, °C", "t_in", 1.0),
    ("Температура выход, °C", "t_out", 1.0),
    ("Расход пара вход, кг/ч", "vapor_flow_in", 3600.0),
    ("Расход пара выход, кг/ч", "vapor_flow_out", 3600.0),
    ("Расход жидкости вход, кг/ч", "liquid_flow_in", 3600.0),
    ("Расход жидкости выход, кг/ч", "liquid_flow_out", 3600.0),
]
# Свойства: (метка, атрибут FluidProperties, масштаб из СИ)
PROP_FIELDS = [
    ("Плотность, кг/м3", "density", 1.0),
    ("Вязкость, сП", "viscosity", 1000.0),
    ("Теплоемкость, кДж/(кг·К)", "cp", 0.001),
    ("Теплопроводность, Вт/(м·К)", "conductivity", 1.0),
]
GEOM_FIELDS = [
    ("Количество труб", "n_tubes", 1.0),
    ("Наружный диаметр, мм", "outer_diameter", 1000.0),
    ("Толщина стенки, мм", "wall_thickness", 1000.0),
    ("Длина трубы, м", "length", 1.0),
    ("Число ходов", "n_passes", 1.0),
    ("Шаг скрутки S, мм", "twist_pitch", 1000.0),
    ("Соотношение осей a/b", "axis_ratio", 1.0),
    ("Диаметр кожуха, мм", "shell_id", 1000.0),
]
CONSTRAINT_FIELDS = [
    ("ΔP макс. shell, кПа", "dp_shell_max", 0.001),
    ("ΔP макс. tube, кПа", "dp_tube_max", 0.001),
    ("P расч. shell, кПа", "p_design_shell", 0.001),
    ("P расч. tube, кПа", "p_design_tube", 0.001),
    ("Поверхность, м2", "surface_area", 1.0),
]


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")
        self.title("Расчёт теплообменников на витых трубах")
        self.geometry("1200x800")

        self.calculator = HeatExchangerCalculator()
        self.parsed: ParsedInput | None = None
        self.calc_result: CalcResult | None = None
        self.opt_result: OptimizationResult | None = None
        self._entries: dict[str, ctk.CTkEntry] = {}

        self.tabs = ctk.CTkTabview(self)
        self.tabs.pack(fill="both", expand=True, padx=8, pady=8)
        self._build_input_tab()
        self._build_calc_tab()
        self._build_opt_tab()
        self._build_plots_tab()
        self._build_export_tab()

    # ==================================================================
    # Вкладка «Исходные данные»
    # ==================================================================
    def _build_input_tab(self) -> None:
        tab = self.tabs.add("Исходные данные")
        top = ctk.CTkFrame(tab)
        top.pack(fill="x", padx=6, pady=6)
        ctk.CTkButton(top, text="Загрузить PDF (HTRI)",
                      command=self.on_load_pdf).pack(side="left", padx=6)
        ctk.CTkButton(top, text="Загрузить проект (JSON)",
                      command=self.on_load_json).pack(side="left", padx=6)
        self.lbl_file = ctk.CTkLabel(top, text="Файл не загружен")
        self.lbl_file.pack(side="left", padx=12)

        scroll = ctk.CTkScrollableFrame(tab)
        scroll.pack(fill="both", expand=True, padx=6, pady=6)

        for col, title in ((1, "Межтрубное пространство"), (2, "Трубное пространство")):
            ctk.CTkLabel(scroll, text=title,
                         font=ctk.CTkFont(weight="bold")).grid(
                row=0, column=col, padx=4, pady=4)

        row = 1
        for label, attr, _ in STREAM_FIELDS:
            ctk.CTkLabel(scroll, text=label, anchor="w").grid(
                row=row, column=0, sticky="w", padx=4)
            for col, side in ((1, "shell"), (2, "tube")):
                e = ctk.CTkEntry(scroll, width=150)
                e.grid(row=row, column=col, padx=4, pady=2)
                self._entries[f"{side}.{attr}"] = e
            row += 1

        ctk.CTkLabel(scroll, text="Свойства сред (вход / выход):",
                     font=ctk.CTkFont(weight="bold")).grid(
            row=row, column=0, columnspan=3, sticky="w", pady=(10, 2))
        row += 1
        for label, attr, _ in PROP_FIELDS:
            ctk.CTkLabel(scroll, text=label, anchor="w").grid(
                row=row, column=0, sticky="w", padx=4)
            for col, side in ((1, "shell"), (2, "tube")):
                frame = ctk.CTkFrame(scroll, fg_color="transparent")
                frame.grid(row=row, column=col)
                for suffix in ("in", "out"):
                    e = ctk.CTkEntry(frame, width=70)
                    e.pack(side="left", padx=2)
                    self._entries[f"{side}.props.{suffix}.{attr}"] = e
            row += 1

        ctk.CTkLabel(scroll, text="Геометрия и ограничения:",
                     font=ctk.CTkFont(weight="bold")).grid(
            row=row, column=0, columnspan=3, sticky="w", pady=(10, 2))
        row += 1
        for i, (label, attr, _) in enumerate(GEOM_FIELDS + CONSTRAINT_FIELDS):
            r, c = divmod(i, 2)
            ctk.CTkLabel(scroll, text=label, anchor="w").grid(
                row=row + r, column=c * 3, sticky="w", padx=4)
            e = ctk.CTkEntry(scroll, width=120)
            e.grid(row=row + r, column=c * 3 + 1, padx=4, pady=2)
            self._entries[f"param.{attr}"] = e

    def on_load_pdf(self) -> None:
        path = filedialog.askopenfilename(
            title="Выберите отчёт HTRI", filetypes=[("PDF", "*.pdf")])
        if not path:
            return
        try:
            self.parsed = parse_htri_pdf(path)
        except Exception as exc:  # noqa: BLE001 — показать пользователю
            messagebox.showerror("Ошибка парсинга", str(exc))
            return
        self.opt_result = None
        self.calc_result = None
        self._fill_table()
        self.lbl_file.configure(text=path)
        if self.parsed.missing_fields:
            messagebox.showwarning(
                "Требуется ручной ввод",
                "Не извлечены поля:\n" + "\n".join(self.parsed.missing_fields))

    def on_load_json(self) -> None:
        path = filedialog.askopenfilename(
            title="Загрузить проект", filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            snap = load_session(path)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Ошибка загрузки", str(exc))
            return
        self.parsed = snap.parsed
        self.calc_result = snap.calc
        self.opt_result = snap.optimization
        self._fill_table()
        self.lbl_file.configure(text=path)
        if self.calc_result:
            self._show_calc_results()

    def _fill_table(self) -> None:
        """Заполнение таблицы из ParsedInput."""
        p = self.parsed
        if p is None:
            return
        for side, stream in (("shell", p.shell), ("tube", p.tube)):
            for _, attr, scale in STREAM_FIELDS:
                self._set_entry(f"{side}.{attr}", getattr(stream, attr), scale)
            for _, attr, scale in PROP_FIELDS:
                for suffix, props in (("in", stream.props_in), ("out", stream.props_out)):
                    value = getattr(props, attr) if props else None
                    self._set_entry(f"{side}.props.{suffix}.{attr}", value, scale)
        g = p.tube_geometry
        for _, attr, scale in GEOM_FIELDS:
            value = (p.shell_geometry.inner_diameter if attr == "shell_id"
                     else getattr(g, attr))
            self._set_entry(f"param.{attr}", value, scale)
        for _, attr, scale in CONSTRAINT_FIELDS:
            value = (p.surface_area if attr == "surface_area"
                     else getattr(p.constraints, attr))
            self._set_entry(f"param.{attr}", value, scale)

    def _set_entry(self, key: str, value, scale: float) -> None:
        entry = self._entries[key]
        entry.delete(0, "end")
        if value is None:
            return
        if isinstance(value, str):
            entry.insert(0, value)
        elif isinstance(value, (int, float)):
            entry.insert(0, f"{value * scale:.6g}")

    def _read_entry(self, key: str, scale: float, as_str: bool = False):
        text = self._entries[key].get().strip().replace(",", ".")
        if as_str:
            return text
        if not text:
            return None
        try:
            return float(text) / scale
        except ValueError:
            return None

    def _apply_table(self) -> bool:
        """Перенос отредактированных значений таблицы в ParsedInput."""
        if self.parsed is None:
            messagebox.showwarning("Нет данных", "Сначала загрузите PDF или проект JSON.")
            return False
        p = self.parsed
        for side, stream in (("shell", p.shell), ("tube", p.tube)):
            for _, attr, scale in STREAM_FIELDS:
                value = self._read_entry(f"{side}.{attr}", scale, as_str=(attr == "fluid_name"))
                if value is not None:
                    setattr(stream, attr, value)
            for _, attr, scale in PROP_FIELDS:
                for suffix in ("in", "out"):
                    value = self._read_entry(f"{side}.props.{suffix}.{attr}", scale)
                    if value is None:
                        continue
                    props = getattr(stream, f"props_{suffix}")
                    if props is None:
                        props = FluidProperties(
                            name=stream.fluid_name,
                            temperature_c=stream.t_in if suffix == "in" else stream.t_out)
                        setattr(stream, f"props_{suffix}", props)
                    setattr(props, attr, value)
        for _, attr, scale in GEOM_FIELDS:
            value = self._read_entry(f"param.{attr}", scale)
            if value is None:
                continue
            if attr == "shell_id":
                p.shell_geometry.inner_diameter = value
            elif attr in ("n_tubes", "n_passes"):
                setattr(p.tube_geometry, attr, max(1, int(round(value))))
            else:
                setattr(p.tube_geometry, attr, value)
        for _, attr, scale in CONSTRAINT_FIELDS:
            value = self._read_entry(f"param.{attr}", scale)
            if attr == "surface_area":
                p.surface_area = value
            elif value is not None:
                setattr(p.constraints, attr, value)
        return True

    # ==================================================================
    # Вкладка «Расчёт»
    # ==================================================================
    def _build_calc_tab(self) -> None:
        tab = self.tabs.add("Расчёт")
        controls = ctk.CTkFrame(tab)
        controls.pack(fill="x", padx=6, pady=6)
        ctk.CTkLabel(controls, text="Двухфазный метод:").pack(side="left", padx=4)
        self.opt_tp = ctk.CTkOptionMenu(controls, values=list(TWO_PHASE_METHODS),
                                        command=self._on_tp_method)
        self.opt_tp.pack(side="left", padx=4)
        ctk.CTkButton(controls, text="Выполнить расчёт",
                      command=self.on_calculate).pack(side="left", padx=12)

        self.txt_calc = ctk.CTkTextbox(tab, font=("Consolas", 12))
        self.txt_calc.pack(fill="both", expand=True, padx=6, pady=6)

    def _on_tp_method(self, value: str) -> None:
        self.calculator.two_phase_method = value

    def on_calculate(self) -> None:
        if not self._apply_table():
            return
        try:
            self.calc_result = self.calculator.calculate(self.parsed)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Ошибка расчёта", str(exc))
            return
        self._show_calc_results()

    def _show_calc_results(self) -> None:
        res = self.calc_result
        if res is None:
            return
        self.txt_calc.delete("1.0", "end")
        self.txt_calc.insert("1.0", generate_report_text(self.parsed, res))

    # ==================================================================
    # Вкладка «Оптимизация»
    # ==================================================================
    def _build_opt_tab(self) -> None:
        tab = self.tabs.add("Оптимизация")
        controls = ctk.CTkFrame(tab)
        controls.pack(fill="x", padx=6, pady=6)
        ctk.CTkLabel(controls, text="a/b:").pack(side="left")
        self.ent_ab = ctk.CTkEntry(controls, width=100)
        self.ent_ab.insert(0, "1.2 - 3.0")
        self.ent_ab.pack(side="left", padx=4)
        ctk.CTkLabel(controls, text="S, м:").pack(side="left")
        self.ent_s = ctk.CTkEntry(controls, width=100)
        self.ent_s.insert(0, "0.1 - 1.0")
        self.ent_s.pack(side="left", padx=4)
        self.btn_opt = ctk.CTkButton(controls, text="Запустить оптимизацию",
                                     command=self.on_optimize)
        self.btn_opt.pack(side="left", padx=12)

        self.txt_opt = ctk.CTkTextbox(tab, font=("Consolas", 12))
        self.txt_opt.pack(fill="both", expand=True, padx=6, pady=6)

    @staticmethod
    def _parse_bounds(entry: ctk.CTkEntry, default: tuple[float, float]) -> tuple[float, float]:
        try:
            parts = [float(v.replace(",", ".")) for v in entry.get().split("-")]
            if len(parts) == 2 and parts[0] < parts[1]:
                return parts[0], parts[1]
        except ValueError:
            pass
        return default

    def on_optimize(self) -> None:
        if not self._apply_table():
            return
        if self.calc_result is None:
            self.calc_result = self.calculator.calculate(self.parsed)
        ab = self._parse_bounds(self.ent_ab, (1.2, 3.0))
        sb = self._parse_bounds(self.ent_s, (0.1, 1.0))
        self.btn_opt.configure(state="disabled", text="Идёт оптимизация...")
        self.txt_opt.delete("1.0", "end")
        self.txt_opt.insert("1.0", "Подбор геометрии, подождите...")

        def worker() -> None:
            optimizer = GeometryOptimizer(self.calculator, ab, sb)
            try:
                result = optimizer.optimize(self.parsed)
            except Exception as exc:  # noqa: BLE001
                self.after(0, lambda: self._opt_failed(exc))
                return
            self.after(0, lambda: self._opt_done(result))

        threading.Thread(target=worker, daemon=True).start()

    def _opt_failed(self, exc: Exception) -> None:
        self.btn_opt.configure(state="normal", text="Запустить оптимизацию")
        messagebox.showerror("Ошибка оптимизации", str(exc))

    def _opt_done(self, result: OptimizationResult) -> None:
        self.opt_result = result
        self.btn_opt.configure(state="normal", text="Запустить оптимизацию")
        self.txt_opt.delete("1.0", "end")
        if not result.success:
            self.txt_opt.insert("1.0", result.message)
            return
        lines = [
            "РЕЗУЛЬТАТ ОПТИМИЗАЦИИ",
            "=" * 50,
            result.message,
            "",
            f"Соотношение осей a/b : {result.best_axis_ratio:.3f}",
            f"Шаг скрутки S        : {result.best_twist_pitch * 1000:.1f} мм",
            f"Коэфф. теплоотдачи h : {result.best_h:.1f} Вт/(м2·К)",
            f"Потери давления ΔP   : {result.best_dp_tube / 1000:.2f} кПа",
            f"Фактор эффективности : Pf = {result.pf:.3f}, PEC = {result.pec:.3f}",
            f"Оценено конфигураций : {len(result.records)}",
            "",
            "Применить найденную геометрию можно кнопкой ниже.",
        ]
        self.txt_opt.insert("1.0", "\n".join(lines))
        if not hasattr(self, "btn_apply_geom"):
            self.btn_apply_geom = ctk.CTkButton(
                self.tabs.tab("Оптимизация"), text="Применить геометрию в исходные данные",
                command=self._apply_opt_geometry)
            self.btn_apply_geom.pack(pady=4)

    def _apply_opt_geometry(self) -> None:
        if self.opt_result and self.opt_result.success:
            self._set_entry("param.twist_pitch", self.opt_result.best_twist_pitch, 1000.0)
            self._set_entry("param.axis_ratio", self.opt_result.best_axis_ratio, 1.0)
            self._apply_table()
            messagebox.showinfo("Готово", "Оптимальная геометрия применена к исходным данным.")

    # ==================================================================
    # Вкладка «Графики»
    # ==================================================================
    def _build_plots_tab(self) -> None:
        tab = self.tabs.add("Графики")
        controls = ctk.CTkFrame(tab)
        controls.pack(fill="x", padx=6, pady=6)
        ctk.CTkButton(controls, text="Re от расхода",
                      command=lambda: self._show_plot("re")).pack(side="left", padx=4)
        ctk.CTkButton(controls, text="ΔP от расхода",
                      command=lambda: self._show_plot("dp")).pack(side="left", padx=4)
        ctk.CTkButton(controls, text="Pf/PEC от шага S",
                      command=lambda: self._show_plot("eff_s")).pack(side="left", padx=4)
        ctk.CTkButton(controls, text="Pf/PEC от a/b",
                      command=lambda: self._show_plot("eff_ab")).pack(side="left", padx=4)
        self.plot_frame = ctk.CTkFrame(tab)
        self.plot_frame.pack(fill="both", expand=True, padx=6, pady=6)
        self._canvas: FigureCanvasTkAgg | None = None

    def _show_plot(self, kind: str) -> None:
        if not self._apply_table():
            return
        builders = {
            "re": reynolds_vs_flow,
            "dp": dp_vs_flow,
            "eff_s": lambda i, c: efficiency_curves(i, c, "twist_pitch"),
            "eff_ab": lambda i, c: efficiency_curves(i, c, "axis_ratio"),
        }
        try:
            fig = builders[kind](self.parsed, self.calculator)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Ошибка построения", str(exc))
            return
        if self._canvas is not None:
            self._canvas.get_tk_widget().destroy()
        self._canvas = FigureCanvasTkAgg(fig, master=self.plot_frame)
        self._canvas.draw()
        self._canvas.get_tk_widget().pack(fill="both", expand=True)

    # ==================================================================
    # Вкладка «Экспорт»
    # ==================================================================
    def _build_export_tab(self) -> None:
        tab = self.tabs.add("Экспорт")
        ctk.CTkButton(tab, text="Экспорт PDF-отчёта",
                      command=self.on_export_pdf).pack(padx=10, pady=8, anchor="w")
        ctk.CTkButton(tab, text="Экспорт XLSX (таблицы)",
                      command=self.on_export_xlsx).pack(padx=10, pady=8, anchor="w")
        ctk.CTkButton(tab, text="Сохранить проект (JSON)",
                      command=self.on_export_json).pack(padx=10, pady=8, anchor="w")
        self.lbl_export = ctk.CTkLabel(tab, text="")
        self.lbl_export.pack(padx=10, pady=8, anchor="w")

    def _ensure_results(self) -> bool:
        if not self._apply_table():
            return False
        if self.calc_result is None:
            self.calc_result = self.calculator.calculate(self.parsed)
        return True

    def on_export_pdf(self) -> None:
        if not self._ensure_results():
            return
        path = filedialog.asksaveasfilename(defaultextension=".pdf",
                                            filetypes=[("PDF", "*.pdf")])
        if not path:
            return
        text = generate_report_text(self.parsed, self.calc_result, self.opt_result)
        try:
            figs = [reynolds_vs_flow(self.parsed, self.calculator),
                    dp_vs_flow(self.parsed, self.calculator)]
            export_pdf(self.parsed, self.calc_result, self.opt_result, text, path, figs)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Ошибка экспорта", str(exc))
            return
        self.lbl_export.configure(text=f"PDF сохранён: {path}")

    def on_export_xlsx(self) -> None:
        if not self._ensure_results():
            return
        path = filedialog.asksaveasfilename(defaultextension=".xlsx",
                                            filetypes=[("Excel", "*.xlsx")])
        if not path:
            return
        try:
            export_xlsx(self.parsed, self.calc_result, self.opt_result, path)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Ошибка экспорта", str(exc))
            return
        self.lbl_export.configure(text=f"XLSX сохранён: {path}")

    def on_export_json(self) -> None:
        if not self._ensure_results():
            return
        path = filedialog.asksaveasfilename(defaultextension=".json",
                                            filetypes=[("JSON", "*.json")])
        if not path:
            return
        snap = SessionSnapshot(parsed=self.parsed, calc=self.calc_result,
                               optimization=self.opt_result)
        try:
            save_session(snap, path)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Ошибка сохранения", str(exc))
            return
        self.lbl_export.configure(text=f"Проект сохранён: {path}")


def run_app() -> None:
    app = App()
    app.mainloop()
