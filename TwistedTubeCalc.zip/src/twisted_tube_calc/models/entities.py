"""Доменные модели данных (раздел 2 ТЗ).

Все величины в СИ, если не указано иное: температура — °C,
давление — Па, расход — кг/с.
"""
from __future__ import annotations

import dataclasses
import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class Phase(str, Enum):
    LIQUID = "liquid"
    VAPOR = "vapor"
    TWO_PHASE = "two_phase"


class FlowRegime(str, Enum):
    LAMINAR = "laminar"
    TRANSITION = "transition"
    TURBULENT = "turbulent"


@dataclass
class FluidProperties:
    """Теплофизические свойства среды при заданной температуре."""

    name: str = ""
    temperature_c: float = 20.0
    density: float = 800.0          # кг/м3
    viscosity: float = 1.0e-3       # Па·с
    conductivity: float = 0.12      # Вт/(м·К)
    cp: float = 2200.0              # Дж/(кг·К)
    phase: Phase = Phase.LIQUID
    vapor_quality: float = 0.0      # массовое паросодержание x (0..1)
    latent_heat: Optional[float] = None  # Дж/кг

    @property
    def prandtl(self) -> float:
        return self.cp * self.viscosity / self.conductivity


@dataclass
class StreamData:
    """Поток одной стороны аппарата (трубное/межтрубное пространство)."""

    fluid_name: str = ""
    mass_flow: float = 0.0          # кг/с, суммарный
    t_in: float = 20.0              # °C
    t_out: float = 20.0             # °C
    props_in: Optional[FluidProperties] = None
    props_out: Optional[FluidProperties] = None
    # Двухфазный режим: расходы фаз, кг/с (None — однофазный поток)
    vapor_flow_in: Optional[float] = None
    vapor_flow_out: Optional[float] = None
    liquid_flow_in: Optional[float] = None
    liquid_flow_out: Optional[float] = None
    inlet_pressure: Optional[float] = None  # Па (изб.)

    @property
    def t_mean(self) -> float:
        return 0.5 * (self.t_in + self.t_out)

    @property
    def mean_props(self) -> Optional[FluidProperties]:
        """Средние свойства потока (по средней температуре)."""
        if self.props_in is None and self.props_out is None:
            return None
        a = self.props_in or self.props_out
        b = self.props_out or self.props_in
        x_in = self.vapor_quality_in
        x_out = self.vapor_quality_out
        x_mean = 0.5 * (x_in + x_out) if (x_in is not None and x_out is not None) else max(
            a.vapor_quality, b.vapor_quality
        )
        phase = Phase.TWO_PHASE if x_mean > 1e-12 else a.phase
        return FluidProperties(
            name=a.name,
            temperature_c=self.t_mean,
            density=0.5 * (a.density + b.density),
            viscosity=0.5 * (a.viscosity + b.viscosity),
            conductivity=0.5 * (a.conductivity + b.conductivity),
            cp=0.5 * (a.cp + b.cp),
            phase=phase,
            vapor_quality=x_mean,
            latent_heat=a.latent_heat or b.latent_heat,
        )

    @property
    def vapor_quality_in(self) -> Optional[float]:
        if self.vapor_flow_in is None or self.mass_flow <= 0:
            return None
        return self.vapor_flow_in / self.mass_flow

    @property
    def vapor_quality_out(self) -> Optional[float]:
        if self.vapor_flow_out is None or self.mass_flow <= 0:
            return None
        return self.vapor_flow_out / self.mass_flow


@dataclass
class TubeGeometry:
    """Геометрия витой эллиптической трубы.

    Полуоси a, b выводятся из внутреннего диаметра исходной круглой
    трубы при сохранении площади сечения: a*b = (d_i/2)^2.
    """

    outer_diameter: float = 0.020   # м, исходной круглой трубы
    wall_thickness: float = 0.002   # м
    length: float = 6.0             # м
    n_tubes: int = 746
    n_passes: int = 2
    layout_pitch: float = 0.025     # м, шаг труб в пучке
    twist_pitch: float = 0.300      # м, шаг скрутки S
    twist_angle: float = 30.0       # град., справочный параметр
    axis_ratio: float = 1.8         # a/b

    @property
    def inner_diameter(self) -> float:
        return self.outer_diameter - 2 * self.wall_thickness

    @property
    def semi_axis_b(self) -> float:
        # a*b = (d_i/2)^2, a/b = r  =>  b = d_i / (2*sqrt(r))
        return self.inner_diameter / (2 * math.sqrt(self.axis_ratio))

    @property
    def semi_axis_a(self) -> float:
        return self.axis_ratio * self.semi_axis_b

    @property
    def cross_area(self) -> float:
        """Площадь свободного сечения одной трубы, м2 (A_c = pi*a*b)."""
        return math.pi * self.semi_axis_a * self.semi_axis_b

    @property
    def ellipse_perimeter(self) -> float:
        """Периметр эллиптического сечения (второе приближение Рамануджана)."""
        a, b = self.semi_axis_a, self.semi_axis_b
        return math.pi * (3 * (a + b) - math.sqrt((3 * a + b) * (a + 3 * b)))

    @property
    def equivalent_diameter(self) -> float:
        """Эквивалентный (гидравлический) диаметр d_e = 4*A_c/P_c."""
        return 4 * self.cross_area / self.ellipse_perimeter

    @property
    def flow_area_total(self) -> float:
        """Суммарное проходное сечение трубного пространства на один ход."""
        n_per_pass = max(1, round(self.n_tubes / max(1, self.n_passes)))
        return self.cross_area * n_per_pass

    @property
    def heat_transfer_area(self) -> float:
        """Поверхность теплообмена по периметру сечения, м2."""
        return self.ellipse_perimeter * self.length * self.n_tubes


@dataclass
class ShellGeometry:
    inner_diameter: float = 0.8     # м, внутренний диаметр кожуха


@dataclass
class Constraints:
    """Ограничения, извлекаемые из PDF (раздел 2.1 ТЗ)."""

    dp_shell_max: Optional[float] = None   # Па
    dp_tube_max: Optional[float] = None    # Па
    p_design_shell: Optional[float] = None  # Па (изб.)
    p_design_tube: Optional[float] = None   # Па (изб.)
    t_design_shell: Optional[float] = None  # °C
    t_design_tube: Optional[float] = None   # °C


@dataclass
class ParsedInput:
    """Результат парсинга отчета HTRI (формы Т-1/Т-2/Т-3)."""

    source_file: str = ""
    position: str = ""                       # позиция (T-1 и т.п.)
    shell: StreamData = field(default_factory=StreamData)
    tube: StreamData = field(default_factory=StreamData)
    tube_geometry: TubeGeometry = field(default_factory=TubeGeometry)
    shell_geometry: ShellGeometry = field(default_factory=ShellGeometry)
    constraints: Constraints = field(default_factory=Constraints)
    surface_area: Optional[float] = None     # м2
    heat_duty: Optional[float] = None        # Вт
    mtd: Optional[float] = None              # °C
    u_dirty: Optional[float] = None          # Вт/(м2·К), загрязненного
    u_clean: Optional[float] = None          # Вт/(м2·К), чистого
    u_service: Optional[float] = None        # Вт/(м2·К), рабочего
    dp_shell_calc: Optional[float] = None    # Па, расчетные потери HTRI
    dp_tube_calc: Optional[float] = None     # Па
    missing_fields: list = field(default_factory=list)


@dataclass
class SideResult:
    """Результат расчета одной стороны аппарата."""

    regime: FlowRegime = FlowRegime.TURBULENT
    velocity: float = 0.0            # м/с
    reynolds: float = 0.0
    prandtl: float = 0.0
    nusselt: float = 0.0
    h: float = 0.0                   # Вт/(м2·К)
    friction_factor: float = 0.0     # Дарси
    dp: float = 0.0                  # Па
    two_phase: bool = False
    vapor_quality: float = 0.0
    warnings: list = field(default_factory=list)


@dataclass
class CalcResult:
    """Сводный результат теплогидравлического расчета."""

    shell: SideResult = field(default_factory=SideResult)
    tube: SideResult = field(default_factory=SideResult)
    lmtd: float = 0.0                # °C
    heat_duty: float = 0.0           # Вт
    u_value: float = 0.0             # Вт/(м2·К), по формуле U=(Qh+Qc)/(2*A*dTlm)
    pf: float = 0.0                  # фактор эффективности (ТЗ, п. 2.3)
    pec: float = 0.0                 # PEC (Yang et al., 2011)
    warnings: list = field(default_factory=list)


@dataclass
class OptimizationRecord:
    """Вектор одной итерации оптимизации (для экспорта в XLSX)."""

    iteration: int
    axis_ratio: float
    twist_pitch: float
    h: float
    dp_tube: float
    pf: float
    pec: float
    feasible: bool


@dataclass
class OptimizationResult:
    success: bool = False
    message: str = ""
    best_axis_ratio: float = 0.0
    best_twist_pitch: float = 0.0
    best_h: float = 0.0
    best_dp_tube: float = 0.0
    pf: float = 0.0
    pec: float = 0.0
    records: list = field(default_factory=list)  # list[OptimizationRecord]


@dataclass
class SessionSnapshot:
    """Снапшот сессии для сериализации в JSON (раздел 2.5 ТЗ)."""

    version: int = 1
    parsed: Optional[ParsedInput] = None
    calc: Optional[CalcResult] = None
    optimization: Optional[OptimizationResult] = None
    notes: str = ""


def _serialize(obj: Any) -> Any:
    if dataclasses.is_dataclass(obj):
        return {f.name: _serialize(getattr(obj, f.name)) for f in dataclasses.fields(obj)}
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, (list, tuple)):
        return [_serialize(v) for v in obj]
    return obj


def to_dict(obj: Any) -> dict:
    return _serialize(obj)


def _deserialize(cls: type, data: Any) -> Any:
    if data is None or not dataclasses.is_dataclass(cls):
        return data
    kwargs = {}
    for f in dataclasses.fields(cls):
        if f.name not in data:
            continue
        value = data[f.name]
        ftype = f.type
        target = _FIELD_TYPES.get((cls.__name__, f.name))
        if target is not None:
            if isinstance(target, list):
                item_cls = target[0]
                value = [_deserialize(item_cls, v) for v in (value or [])]
            else:
                value = _deserialize(target, value)
        elif ftype is not None and "Phase" in str(ftype) and value is not None:
            value = Phase(value)
        elif ftype is not None and "FlowRegime" in str(ftype) and value is not None:
            value = FlowRegime(value)
        kwargs[f.name] = value
    return cls(**kwargs)


_FIELD_TYPES: dict = {
    ("ParsedInput", "shell"): StreamData,
    ("ParsedInput", "tube"): StreamData,
    ("ParsedInput", "tube_geometry"): TubeGeometry,
    ("ParsedInput", "shell_geometry"): ShellGeometry,
    ("ParsedInput", "constraints"): Constraints,
    ("StreamData", "props_in"): FluidProperties,
    ("StreamData", "props_out"): FluidProperties,
    ("CalcResult", "shell"): SideResult,
    ("CalcResult", "tube"): SideResult,
    ("OptimizationResult", "records"): [OptimizationRecord],
    ("SessionSnapshot", "parsed"): ParsedInput,
    ("SessionSnapshot", "calc"): CalcResult,
    ("SessionSnapshot", "optimization"): OptimizationResult,
}


def from_dict(cls: type, data: dict) -> Any:
    return _deserialize(cls, data)
