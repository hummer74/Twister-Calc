"""Модуль многокритериальной оптимизации геометрии витой трубы (п. 2.3 ТЗ).

Целевая функция: Pf = (h/h_ref)/(dP/dP_ref) -> max, где h_ref, dP_ref —
значения для гладкой круглой трубы при том же Re. Дополнительно
вычисляется PEC = (Nu/Nu0)/(f/f0)^(1/3) (Yang et al., 2011).

Варьируемые параметры: соотношение осей a/b и шаг скрутки S.
Ограничения (из отчетов HTRI): dP_tube <= dP_tube_max,
dP_shell <= dP_shell_max; нарушающие конфигурации отбрасываются.
"""
from __future__ import annotations

import dataclasses
from typing import Optional

import numpy as np
from scipy.optimize import differential_evolution

from ..core import HeatExchangerCalculator
from ..models import (
    Constraints,
    OptimizationRecord,
    OptimizationResult,
    ParsedInput,
    TubeGeometry,
)


class GeometryOptimizer:
    def __init__(self, calculator: Optional[HeatExchangerCalculator] = None,
                 axis_ratio_bounds: tuple[float, float] = (1.2, 3.0),
                 twist_pitch_bounds: tuple[float, float] = (0.10, 1.00)):
        self.calculator = calculator or HeatExchangerCalculator()
        self.axis_ratio_bounds = axis_ratio_bounds
        self.twist_pitch_bounds = twist_pitch_bounds

    # ------------------------------------------------------------------
    def _evaluate(self, inp: ParsedInput, axis_ratio: float,
                  twist_pitch: float) -> tuple[float, float, float, float, bool]:
        """(pf, pec, h, dp_tube, feasible) для заданной геометрии."""
        geom = dataclasses.replace(inp.tube_geometry,
                                   axis_ratio=axis_ratio, twist_pitch=twist_pitch)
        res = self.calculator.calculate(inp, geom=geom)
        dp_tube = res.tube.dp
        dp_shell = res.shell.dp
        cons: Constraints = inp.constraints
        feasible = True
        if cons.dp_tube_max is not None and dp_tube > cons.dp_tube_max:
            feasible = False
        if cons.dp_shell_max is not None and dp_shell > 0 and dp_shell > cons.dp_shell_max:
            feasible = False
        return res.pf, res.pec, res.tube.h, dp_tube, feasible

    # ------------------------------------------------------------------
    def optimize(self, inp: ParsedInput, maxiter: int = 40,
                 seed: int = 42) -> OptimizationResult:
        """Глобальная оптимизация (differential_evolution) с ограничениями."""
        result = OptimizationResult()
        records: list[OptimizationRecord] = []
        counter = {"i": 0}

        # Базовая точка — текущая геометрия из отчета
        base = self._evaluate(inp, inp.tube_geometry.axis_ratio,
                              inp.tube_geometry.twist_pitch)

        def objective(x: np.ndarray) -> float:
            counter["i"] += 1
            axis_ratio, twist_pitch = float(x[0]), float(x[1])
            try:
                pf, pec, h, dp_tube, feasible = self._evaluate(
                    inp, axis_ratio, twist_pitch)
            except Exception:
                return 1e6
            records.append(OptimizationRecord(
                iteration=counter["i"], axis_ratio=axis_ratio,
                twist_pitch=twist_pitch, h=h, dp_tube=dp_tube,
                pf=pf, pec=pec, feasible=feasible))
            if not feasible or pf <= 0 or not np.isfinite(pf):
                return 1e6
            return -pf  # максимизация

        bounds = [self.axis_ratio_bounds, self.twist_pitch_bounds]
        de = differential_evolution(objective, bounds, maxiter=maxiter,
                                    seed=seed, polish=True, tol=1e-7)
        result.records = records

        feasible_records = [r for r in records if r.feasible and r.pf > 0]
        if de.success and np.isfinite(de.fun) and de.fun < 0:
            pf, pec, h, dp_tube, _ = self._evaluate(inp, float(de.x[0]), float(de.x[1]))
            result.success = True
            result.best_axis_ratio = float(de.x[0])
            result.best_twist_pitch = float(de.x[1])
            result.best_h = h
            result.best_dp_tube = dp_tube
            result.pf = pf
            result.pec = pec
            result.message = "Оптимум найден."
        elif feasible_records:
            best = max(feasible_records, key=lambda r: r.pf)
            result.success = True
            result.best_axis_ratio = best.axis_ratio
            result.best_twist_pitch = best.twist_pitch
            result.best_h = best.h
            result.best_dp_tube = best.dp_tube
            result.pf = best.pf
            result.pec = best.pec
            result.message = "Оптимизатор не сошелся; выбрана лучшая допустимая точка."
        else:
            result.success = False
            result.message = ("Не найдено допустимых конфигураций: ограничения "
                              "по потерям давления слишком жесткие.")
        result.message += f" Базовая геометрия: Pf={base[0]:.3f}."
        return result
