"""Golden-тесты парсера на эталонных отчетах HTRI (Т-1/Т-2/Т-3)."""
import os

import pytest

from twisted_tube_calc.parsers import parse_htri_pdf

FIXTURES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures")


@pytest.fixture(params=["T-1.pdf", "T-2.pdf", "T-3.pdf"])
def parsed(request):
    return parse_htri_pdf(os.path.join(FIXTURES, request.param))


class TestGolden:
    def test_t1(self):
        r = parse_htri_pdf(os.path.join(FIXTURES, "T-1.pdf"))
        assert r.position == "T-1"
        assert "Мазут" in r.shell.fluid_name
        assert r.tube.fluid_name == "Нефть"
        assert r.shell.mass_flow == pytest.approx(90000 / 3600)
        assert r.tube.mass_flow == pytest.approx(107700 / 3600)
        assert r.shell.t_in == pytest.approx(347.80)
        assert r.shell.t_out == pytest.approx(261.80)
        assert r.tube.t_in == pytest.approx(174.30)
        assert r.tube.t_out == pytest.approx(245.26)
        # Свойства (жидкая фаза пар "пар/жидкость")
        assert r.shell.props_in.density == pytest.approx(683.9)
        assert r.shell.props_out.viscosity == pytest.approx(1.3438e-3)
        assert r.tube.props_in.cp == pytest.approx(2515.3)
        assert r.tube.props_in.conductivity == pytest.approx(0.0988)
        assert r.tube.props_in.latent_heat == pytest.approx(327880)
        # Двухфазный поток в трубах
        assert r.tube.vapor_flow_in == pytest.approx(3019.9 / 3600)
        assert r.tube.vapor_flow_out == pytest.approx(17186 / 3600)
        # Ограничения
        assert r.constraints.dp_shell_max == pytest.approx(50000)
        assert r.constraints.dp_tube_max == pytest.approx(100000)
        assert r.dp_shell_calc == pytest.approx(32000)
        assert r.dp_tube_calc == pytest.approx(62400)
        assert r.constraints.p_design_shell == pytest.approx(1680000)
        assert r.constraints.p_design_tube == pytest.approx(2180000)
        assert r.constraints.t_design_shell == pytest.approx(355)
        assert r.constraints.t_design_tube == pytest.approx(260)
        # Геометрия
        g = r.tube_geometry
        assert g.n_tubes == 746
        assert g.outer_diameter == pytest.approx(0.020)
        assert g.wall_thickness == pytest.approx(0.002)
        assert g.length == pytest.approx(6.0)
        assert g.n_passes == 2
        assert g.twist_angle == pytest.approx(30.0)
        assert r.shell_geometry.inner_diameter == pytest.approx(0.8)
        assert r.surface_area == pytest.approx(281.24)
        assert r.heat_duty == pytest.approx(6268000)
        assert r.mtd == pytest.approx(90.3)
        assert r.missing_fields == []

    def test_t2(self):
        r = parse_htri_pdf(os.path.join(FIXTURES, "T-2.pdf"))
        assert r.position == "T-2"
        assert r.shell.t_in == pytest.approx(205.35)
        assert r.shell.t_out == pytest.approx(170.22)
        assert r.tube.t_in == pytest.approx(148.1)
        assert r.tube.t_out == pytest.approx(177.97)
        assert r.tube_geometry.n_tubes == 1807
        assert r.shell_geometry.inner_diameter == pytest.approx(1.2)
        assert r.constraints.dp_shell_max == pytest.approx(50000)
        assert r.constraints.dp_tube_max == pytest.approx(50000)
        assert r.surface_area == pytest.approx(681.22)
        assert r.heat_duty == pytest.approx(2201000)
        assert r.mtd == pytest.approx(22.5)
        assert r.missing_fields == []

    def test_t3(self):
        r = parse_htri_pdf(os.path.join(FIXTURES, "T-3.pdf"))
        assert r.position == "T-3"
        assert r.shell.t_in == pytest.approx(261.80)
        assert r.tube.t_in == pytest.approx(177.97)
        assert r.tube.t_out == pytest.approx(222.14)
        assert r.tube_geometry.n_tubes == 1807
        assert r.constraints.dp_tube_max == pytest.approx(100000)
        assert r.heat_duty == pytest.approx(4242000)
        assert r.mtd == pytest.approx(30.5)
        assert r.missing_fields == []

    def test_all_fixtures_complete(self, parsed):
        # Все ключевые поля заполнены для каждого образца
        assert parsed.shell.mass_flow > 0
        assert parsed.tube.mass_flow > 0
        assert parsed.tube.props_in is not None
        assert parsed.tube.props_out is not None
        assert parsed.constraints.dp_tube_max is not None


class TestRobustness:
    def test_missing_file(self):
        with pytest.raises(Exception):
            parse_htri_pdf(os.path.join(FIXTURES, "nonexistent.pdf"))
