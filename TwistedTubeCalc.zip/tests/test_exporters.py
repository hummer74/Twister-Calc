"""Тесты экспорта: JSON round-trip, XLSX, PDF."""
import os

import openpyxl
import pdfplumber
import pytest

from twisted_tube_calc.core import HeatExchangerCalculator
from twisted_tube_calc.exporters import (
    export_pdf,
    export_xlsx,
    load_session,
    save_session,
)
from twisted_tube_calc.models import SessionSnapshot
from twisted_tube_calc.parsers import parse_htri_pdf
from twisted_tube_calc.viz import dp_vs_flow, generate_report_text

FIXTURES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures")


@pytest.fixture(scope="module")
def bundle():
    inp = parse_htri_pdf(os.path.join(FIXTURES, "T-1.pdf"))
    calc = HeatExchangerCalculator()
    res = calc.calculate(inp)
    return inp, calc, res


def test_json_round_trip(bundle, tmp_path):
    inp, calc, res = bundle
    snap = SessionSnapshot(parsed=inp, calc=res, notes="тест")
    path = str(tmp_path / "session.json")
    save_session(snap, path)
    loaded = load_session(path)
    assert loaded.parsed.tube.fluid_name == inp.tube.fluid_name
    assert loaded.parsed.tube_geometry.n_tubes == inp.tube_geometry.n_tubes
    assert loaded.parsed.constraints.dp_tube_max == inp.constraints.dp_tube_max
    assert loaded.calc.tube.reynolds == pytest.approx(res.tube.reynolds, rel=1e-12)
    assert loaded.calc.pec == pytest.approx(res.pec, rel=1e-12)
    assert loaded.notes == "тест"
    # Повторная загрузка дает идентичный расчет
    recalc = HeatExchangerCalculator().calculate(loaded.parsed)
    assert recalc.tube.nusselt == pytest.approx(res.tube.nusselt, rel=1e-9)
    assert recalc.tube.dp == pytest.approx(res.tube.dp, rel=1e-9)


def test_xlsx_export(bundle, tmp_path):
    inp, _, res = bundle
    path = str(tmp_path / "report.xlsx")
    export_xlsx(inp, res, None, path)
    wb = openpyxl.load_workbook(path)
    assert "Исходные данные" in wb.sheetnames
    assert "Результаты" in wb.sheetnames
    sheet = wb["Результаты"]
    values = {row[0]: row[1] for row in sheet.iter_rows(min_row=2, values_only=True)}
    assert values["Re"] == pytest.approx(round(res.tube.reynolds, 1))


def test_pdf_export(bundle, tmp_path):
    inp, calc, res = bundle
    path = str(tmp_path / "report.pdf")
    text = generate_report_text(inp, res)
    export_pdf(inp, res, None, text, path, figures=[dp_vs_flow(inp, calc)])
    assert os.path.getsize(path) > 10000
    with pdfplumber.open(path) as pdf:
        content = "\n".join(p.extract_text() or "" for p in pdf.pages)
    assert "Сводный отчет" in content
    assert "Пояснительная записка" in content
    assert "Мазутная фракция" in content
