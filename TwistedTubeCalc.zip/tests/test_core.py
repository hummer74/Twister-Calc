"""Тесты расчетного ядра: геометрия, корреляции, режимы, LMTD, U."""
import math

import pytest

from twisted_tube_calc.core import (
    CorrelationSelector,
    LaminarTwistedTube,
    TurbulentYang2011,
    smooth_tube_friction,
    smooth_tube_nusselt,
)
from twisted_tube_calc.core import hydraulics, thermal
from twisted_tube_calc.models import FlowRegime, TubeGeometry


@pytest.fixture
def geom():
    return TubeGeometry(outer_diameter=0.020, wall_thickness=0.002,
                        length=6.0, n_tubes=100, n_passes=2,
                        twist_pitch=0.3, axis_ratio=2.0)


class TestGeometry:
    def test_circle_degenerates(self):
        # a/b = 1 -> круглое сечение: d_e == d_i, A_c == pi*d_i^2/4
        g = TubeGeometry(outer_diameter=0.020, wall_thickness=0.002, axis_ratio=1.0)
        d_i = 0.016
        assert g.cross_area == pytest.approx(math.pi * d_i**2 / 4, rel=1e-6)
        assert g.ellipse_perimeter == pytest.approx(math.pi * d_i, rel=1e-3)
        assert g.equivalent_diameter == pytest.approx(d_i, rel=1e-3)

    def test_ellipse_area_and_de(self, geom):
        a, b = geom.semi_axis_a, geom.semi_axis_b
        assert a / b == pytest.approx(2.0)
        # Площадь сохраняется относительно исходной круглой трубы
        assert math.pi * a * b == pytest.approx(
            math.pi * geom.inner_diameter**2 / 4, rel=1e-9)
        # Рамануджан: периметр эллипса > периметра круга той же площади
        assert geom.ellipse_perimeter > math.pi * geom.inner_diameter
        assert geom.equivalent_diameter < geom.inner_diameter


class TestYangCorrelations:
    def test_manual_recalc(self, geom):
        # Ручной пересчет корреляций Yang et al. (2011)
        re, pr = 10000.0, 10.0
        d_e = geom.equivalent_diameter
        s_over_de = geom.twist_pitch / d_e
        nu_expected = (0.023 * re**0.8 * pr**0.4
                       * (1 + 3.54 * 2.0**0.357 * s_over_de**-0.55))
        f_expected = (0.3164 * re**-0.25
                      * (1 + 2.08 * 2.0**0.89 * s_over_de**-0.63))
        corr = TurbulentYang2011()
        assert corr.nusselt(re, pr, geom) == pytest.approx(nu_expected, rel=1e-12)
        assert corr.friction(re, geom) == pytest.approx(f_expected, rel=1e-12)

    def test_degenerates_to_smooth(self):
        # a/b -> 1 и S -> inf: корреляции вырождаются в Nu0/f0 (точность < 0.1%)
        g = TubeGeometry(axis_ratio=1.0, twist_pitch=1e6)
        corr = TurbulentYang2011()
        re, pr = 10000.0, 10.0
        assert corr.nusselt(re, pr, g) == pytest.approx(
            smooth_tube_nusselt(re, pr), rel=1e-3)
        assert corr.friction(re, g) == pytest.approx(
            smooth_tube_friction(re), rel=1e-3)


class TestRegimeSelection:
    def test_laminar(self, geom):
        sel = CorrelationSelector()
        nu, regime, w = sel.nusselt(1000.0, 50.0, geom)
        assert regime is FlowRegime.LAMINAR
        assert not w
        assert nu > 0

    def test_transition_warns(self, geom):
        sel = CorrelationSelector()
        _, regime, w = sel.nusselt(4000.0, 10.0, geom)
        assert regime is FlowRegime.TRANSITION
        assert any("переходной" in x for x in w)

    def test_turbulent_out_of_range_warns(self, geom):
        sel = CorrelationSelector()
        _, regime, w = sel.nusselt(80000.0, 10.0, geom)
        assert regime is FlowRegime.TURBULENT
        assert any("экстраполяция" in x for x in w)

    def test_transition_between_laminar_and_turbulent(self, geom):
        sel = CorrelationSelector()
        nu_lam = sel.nusselt(2000.0, 10.0, geom)[0]
        nu_turb = sel.nusselt(7000.0, 10.0, geom)[0]
        nu_mid = sel.nusselt(4000.0, 10.0, geom)[0]
        assert min(nu_lam, nu_turb) * 0.5 < nu_mid < max(nu_lam, nu_turb) * 2


class TestThermal:
    def test_lmtd(self):
        assert thermal.lmtd(100.0, 50.0) == pytest.approx(72.1348, abs=1e-3)
        assert thermal.lmtd(80.0, 80.0) == pytest.approx(80.0)
        with pytest.raises(ValueError):
            thermal.lmtd(-10.0, 50.0)

    def test_lmtd_countercurrent(self):
        # Горячий 347.8->261.8, холодный 174.3->245.26 (Т-1)
        value = thermal.lmtd_countercurrent(347.8, 261.8, 174.3, 245.26)
        assert value == pytest.approx(94.82, abs=0.05)

    def test_overall_u(self):
        assert thermal.overall_u(1e6, 1e6, 100.0, 50.0) == pytest.approx(200.0)

    def test_pressure_drop(self):
        # f=0.05, L=12, d=0.016, rho=700, u=2
        dp = hydraulics.pressure_drop(0.05, 12.0, 0.016, 700.0, 2.0)
        assert dp == pytest.approx(0.05 * (12 / 0.016) * 700 * 4 / 2, rel=1e-12)

    def test_heat_duty_with_phase_change(self):
        q = thermal.heat_duty_with_phase_change(
            10.0, 2500.0, 100.0, 200.0, 0.5, 2.0, 300000.0)
        assert q == pytest.approx(10 * 2500 * 100 + 1.5 * 300000, rel=1e-12)


class TestLaminarFallback:
    def test_laminar_model_positive(self, geom):
        model = LaminarTwistedTube()
        assert model.nusselt(500.0, 100.0, geom) > 0
        assert model.friction(500.0, geom) > 64.0 / 500.0  # выше гладкой трубы
