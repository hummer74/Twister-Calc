"""Тесты модуля оптимизации."""
import dataclasses
import os

import pytest

from twisted_tube_calc.core import HeatExchangerCalculator
from twisted_tube_calc.optimizer import GeometryOptimizer
from twisted_tube_calc.parsers import parse_htri_pdf

FIXTURES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures")


@pytest.fixture(scope="module")
def inp():
    return parse_htri_pdf(os.path.join(FIXTURES, "T-1.pdf"))


@pytest.fixture(scope="module")
def calc():
    return HeatExchangerCalculator()


def test_optimizer_improves_pf(inp, calc):
    """Pf оптимума не хуже базовой геометрии."""
    base = calc.calculate(inp)
    opt = GeometryOptimizer(calc)
    result = opt.optimize(inp, maxiter=4)
    assert result.success
    assert result.pf >= base.pf - 1e-9


def test_optimizer_respects_constraints(inp, calc):
    """Ни одно принятое решение не нарушает ограничения по ΔP."""
    opt = GeometryOptimizer(calc)
    result = opt.optimize(inp, maxiter=4)
    assert result.success
    if inp.constraints.dp_tube_max is not None:
        assert result.best_dp_tube <= inp.constraints.dp_tube_max * (1 + 1e-9)


def test_optimizer_rejects_infeasible(inp, calc):
    """При жестком лимите ΔP недопустимые конфигурации отбрасываются."""
    tight = dataclasses.replace(inp)
    tight.constraints = dataclasses.replace(inp.constraints,
                                            dp_tube_max=1.0)  # 1 Па — недостижимо
    opt = GeometryOptimizer(calc)
    result = opt.optimize(tight, maxiter=2)
    assert result.success is False
    assert result.records, "итерации должны логироваться"
    assert not any(r.feasible and r.pf > 0 for r in result.records)


def test_optimization_records_logged(inp, calc):
    """Векторы итераций логируются для экспорта в XLSX."""
    opt = GeometryOptimizer(calc)
    result = opt.optimize(inp, maxiter=3)
    assert len(result.records) > 0
    r = result.records[0]
    assert r.axis_ratio > 0 and r.twist_pitch > 0
