"""Тесты двухфазного ядра."""
import dataclasses

import pytest

from twisted_tube_calc.core import HeatExchangerCalculator
from twisted_tube_calc.core.two_phase import (
    lm_pressure_multiplier_liquid,
    lockhart_martinelli_X_tt,
)
from twisted_tube_calc.models import ParsedInput, StreamData, TubeGeometry


def make_input(vapor_in: float, vapor_out: float) -> ParsedInput:
    """Поток нефти 30 кг/с с заданными расходами пара (кг/с)."""
    inp = ParsedInput()
    inp.tube = StreamData(fluid_name="Нефть", mass_flow=30.0,
                          t_in=174.3, t_out=245.26,
                          vapor_flow_in=vapor_in, vapor_flow_out=vapor_out,
                          liquid_flow_in=30.0 - vapor_in,
                          liquid_flow_out=30.0 - vapor_out)
    inp.shell = StreamData(fluid_name="Мазут", mass_flow=25.0,
                           t_in=347.8, t_out=261.8)
    inp.tube_geometry = TubeGeometry(n_tubes=746, n_passes=2, length=6.0)
    return inp


class TestTwoPhaseCore:
    def test_zero_quality_matches_single_phase(self):
        # x=0: двухфазный расчет совпадает с однофазным
        single = make_input(0.0, 0.0)
        single.tube.vapor_flow_in = single.tube.vapor_flow_out = None
        two_phase = make_input(0.0, 0.0)
        calc = HeatExchangerCalculator()
        r1 = calc.calculate(single).tube
        r2 = calc.calculate(two_phase).tube
        assert r2.two_phase is False
        assert r2.dp == pytest.approx(r1.dp, rel=1e-9)
        assert r2.nusselt == pytest.approx(r1.nusselt, rel=1e-9)

    def test_dp_monotonic_in_quality(self):
        # ΔP (Локхарт-Мартинелли) монотонно растет по паросодержанию
        calc = HeatExchangerCalculator(two_phase_method="lockhart-martinelli")
        dps = []
        for x in (0.0, 0.05, 0.15, 0.30):
            inp = make_input(30.0 * x, 30.0 * x)
            dps.append(calc.calculate(inp).tube.dp)
        assert all(a < b for a, b in zip(dps, dps[1:]))

    def test_two_phase_flag_and_quality(self):
        calc = HeatExchangerCalculator()
        inp = make_input(1.5, 3.0)  # x_in=0.05, x_out=0.1
        res = calc.calculate(inp).tube
        assert res.two_phase is True
        assert res.vapor_quality == pytest.approx(0.075, rel=1e-9)

    def test_duty_includes_latent(self):
        calc = HeatExchangerCalculator()
        inp_single = make_input(0.0, 0.0)
        inp_single.tube.vapor_flow_in = inp_single.tube.vapor_flow_out = None
        inp_two = make_input(1.5, 3.0)
        q1 = calc.calculate(inp_single).heat_duty
        q2 = calc.calculate(inp_two).heat_duty
        # Рост паросодержания добавляет скрытую теплоту в баланс
        assert q2 > q1


class TestLockhartMartinelli:
    def test_x_tt(self):
        x_tt = lockhart_martinelli_X_tt(0.1, 700.0, 8.0, 5e-4, 1.1e-5)
        expected = 9.0**0.9 * (8.0 / 700.0)**0.5 * (5e-4 / 1.1e-5)**0.1
        assert x_tt == pytest.approx(expected, rel=1e-12)

    def test_multiplier_bounds(self):
        # x=0 -> Phi_l^2 = 1; x>0 -> Phi_l^2 > 1
        assert lm_pressure_multiplier_liquid(0.0, 700.0, 8.0, 5e-4, 1.1e-5) == 1.0
        assert lm_pressure_multiplier_liquid(0.1, 700.0, 8.0, 5e-4, 1.1e-5) > 1.0

    def test_multiplier_monotonic(self):
        xs = [0.01, 0.05, 0.1, 0.2, 0.4]
        ms = [lm_pressure_multiplier_liquid(x, 700.0, 8.0, 5e-4, 1.1e-5) for x in xs]
        assert all(a < b for a, b in zip(ms, ms[1:]))
