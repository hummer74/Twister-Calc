"""Тесты блока свойств сред: интерполяция, смешение, приоритет HTRI."""
import pytest

from twisted_tube_calc.fluids import FluidModel
from twisted_tube_calc.models import FluidProperties, Phase


@pytest.fixture
def fluids():
    return FluidModel()


class TestInterpolation:
    def test_node_values_mazut(self, fluids):
        # Узловые значения из отчета HTRI Т-2 (170 C)
        p = fluids.liquid_props("мазут", 170.0)
        assert p.density == pytest.approx(808.2, rel=1e-6)
        assert p.viscosity == pytest.approx(0.003587, rel=1e-6)
        assert p.conductivity == pytest.approx(0.1445, rel=1e-6)
        assert p.cp == pytest.approx(2439.4, rel=1e-6)

    def test_node_values_oil(self, fluids):
        # Узловые значения из отчета HTRI Т-1 (245 C)
        p = fluids.liquid_props("нефть", 245.0)
        assert p.density == pytest.approx(695.8, rel=1e-6)
        assert p.cp == pytest.approx(2743.8, rel=1e-6)

    def test_intermediate_monotonic(self, fluids):
        t = [100.0, 150.0, 200.0, 250.0, 300.0]
        rho = [fluids.liquid_props("мазут", x).density for x in t]
        mu = [fluids.liquid_props("мазут", x).viscosity for x in t]
        cp = [fluids.liquid_props("мазут", x).cp for x in t]
        assert all(a > b for a, b in zip(rho, rho[1:]))   # плотность падает
        assert all(a > b for a, b in zip(mu, mu[1:]))     # вязкость падает
        assert all(a < b for a, b in zip(cp, cp[1:]))     # теплоемкость растет

    def test_midpoint_linear(self, fluids):
        # Середина между узлами 170 и 205 C: линейная интерполяция плотности
        p = fluids.liquid_props("мазут", 187.5)
        assert p.density == pytest.approx((808.2 + 785.4) / 2, rel=1e-3)


class TestMixture:
    def test_x0_equals_liquid(self, fluids):
        m = fluids.mixture_props("нефть", 200.0, 0.0)
        l = fluids.liquid_props("нефть", 200.0)
        assert m.phase is Phase.LIQUID
        assert m.density == pytest.approx(l.density, rel=1e-12)
        assert m.viscosity == pytest.approx(l.viscosity, rel=1e-12)

    def test_x1_equals_vapor(self, fluids):
        m = fluids.mixture_props("нефть", 200.0, 1.0)
        v = fluids.vapor_props("нефть", 200.0)
        assert m.density == pytest.approx(v.density, rel=1e-9)
        assert m.cp == pytest.approx(v.cp, rel=1e-9)

    def test_mixture_between_phases(self, fluids):
        m = fluids.mixture_props("нефть", 200.0, 0.1)
        l = fluids.liquid_props("нефть", 200.0)
        v = fluids.vapor_props("нефть", 200.0)
        assert v.density < m.density < l.density
        assert v.viscosity < m.viscosity < l.viscosity
        assert m.phase is Phase.TWO_PHASE
        assert m.latent_heat is not None

    def test_harmonic_density(self, fluids):
        x = 0.05
        l = fluids.liquid_props("нефть", 200.0)
        v = fluids.vapor_props("нефть", 200.0)
        m = fluids.mixture_props("нефть", 200.0, x)
        expected = 1.0 / ((1 - x) / l.density + x / v.density)
        assert m.density == pytest.approx(expected, rel=1e-12)

    def test_liquid_override_priority(self, fluids):
        # Значения из отчета HTRI имеют приоритет над справочными
        override = FluidProperties(name="нефть", temperature_c=200.0,
                                   density=700.0, viscosity=5e-4,
                                   conductivity=0.1, cp=2400.0)
        p = fluids.liquid_props("нефть", 200.0, override=override)
        assert p.density == 700.0
        m = fluids.mixture_props("нефть", 200.0, 0.0, liquid_override=override)
        assert m.density == 700.0
