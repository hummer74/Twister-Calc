"""Интеграционный тест: полный цикл PDF -> расчет -> оптимизация -> экспорт."""
import os

from twisted_tube_calc.core import HeatExchangerCalculator
from twisted_tube_calc.exporters import export_pdf, export_xlsx, save_session
from twisted_tube_calc.models import SessionSnapshot
from twisted_tube_calc.optimizer import GeometryOptimizer
from twisted_tube_calc.parsers import parse_htri_pdf
from twisted_tube_calc.viz import dp_vs_flow, generate_report_text, reynolds_vs_flow

FIXTURES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures")


def test_full_cycle(tmp_path):
    inp = parse_htri_pdf(os.path.join(FIXTURES, "T-1.pdf"))
    calc = HeatExchangerCalculator()
    res = calc.calculate(inp)
    assert res.tube.reynolds > 0
    assert res.lmtd > 0
    assert res.u_value > 0

    opt = GeometryOptimizer(calc).optimize(inp, maxiter=3)
    assert opt.success
    assert opt.pf >= res.pf - 1e-9

    text = generate_report_text(inp, res, opt)
    assert "витой трубы" in text

    export_pdf(inp, res, opt, text, str(tmp_path / "report.pdf"),
               figures=[reynolds_vs_flow(inp, calc), dp_vs_flow(inp, calc)])
    export_xlsx(inp, res, opt, str(tmp_path / "report.xlsx"))
    save_session(SessionSnapshot(parsed=inp, calc=res, optimization=opt),
                 str(tmp_path / "project.json"))
    for name in ("report.pdf", "report.xlsx", "project.json"):
        assert (tmp_path / name).stat().st_size > 1000
